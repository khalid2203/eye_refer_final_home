import { Router } from "express";
import { registerUser, loginUser, verifyUser, getUser, getDocList, getPatientList, addPatient, addAddress, getDoctorList, updateprofile, changePassword, addStaff, getStaffList, addAppointment, getAppointments, deleteAddress, deleteAppoinment, getPatientDetails, getAppointmentDetails, updateAppointment, updatePatientDetails, deleteStaff, updatePatientStatus, downloadStaff, updateProfileImage, deletePatient, getDashboardTime } from "../controllers/userController";
import userAuthMiddleware from "../middlewares/userAuth";
import signupValidation from "../middlewares/formValidation.ts/signupValidation";
import loginValidation from "../middlewares/formValidation.ts/loginValidation";
import { upload } from "../middlewares/upload";
import { validatePatient } from "../middlewares/formValidation.ts/patientValidation";
import { validateStaff } from "../middlewares/formValidation.ts/staffValidation";
import { validateAppointment } from "../middlewares/formValidation.ts/appointmentValidation";

const router = Router();

router.post("/register", signupValidation, registerUser);
router.post("/login", loginValidation, loginUser);
router.put("/verify", verifyUser);
router.get('/user', userAuthMiddleware, getUser);
router.get('/doc-list', userAuthMiddleware, getDocList);
router.get('/doctor-list', userAuthMiddleware, getDoctorList);
router.get('/patient-list', userAuthMiddleware, getPatientList);
router.get('/patient-details/:patientId',userAuthMiddleware, getPatientDetails);
router.delete('/delete-patient/:patientId',userAuthMiddleware, deletePatient);
router.put('/update-patient/:patientId',upload.single('document'),userAuthMiddleware,validatePatient, updatePatientDetails);
router.get('/download-staff',userAuthMiddleware, downloadStaff);
router.put('/update-patient-status',userAuthMiddleware, updatePatientStatus);
router.get('/appointment-details/:appointmentId',userAuthMiddleware, getAppointmentDetails);
router.put('/update-appointment/:appointmentId',userAuthMiddleware,validateAppointment, updateAppointment);
router.post('/add-patient',upload.single('document'), userAuthMiddleware,validatePatient, addPatient);
router.post('/add-address', userAuthMiddleware, addAddress);
router.delete('/delete-address/:addressId', userAuthMiddleware, deleteAddress);
router.post('/add-staff', userAuthMiddleware,validateStaff, addStaff);
router.get('/get-staff', userAuthMiddleware, getStaffList);
router.post('/add-appoinment', userAuthMiddleware,validateAppointment, addAppointment);
router.get('/get-appoinment', userAuthMiddleware, getAppointments);
router.get('/get-timing', userAuthMiddleware, getDashboardTime);
router.delete('/delete-appointment/:appointmentId', userAuthMiddleware, deleteAppoinment);
router.delete('/delete-staff/:staffId', userAuthMiddleware, deleteStaff);
router.post('/update-profile', userAuthMiddleware, updateprofile);
router.put('/update-profile-img',upload.single('profile_photo'),userAuthMiddleware, updateProfileImage);
router.post("/change-password", userAuthMiddleware, changePassword);

export default router;

