import { Model, DataTypes } from "sequelize";
import sequelize from "../config/db";