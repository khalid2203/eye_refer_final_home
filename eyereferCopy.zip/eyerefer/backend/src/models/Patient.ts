import { Model, DataTypes } from "sequelize";
import sequelize from "../config/db";
import { v4 as UUIDV4 } from "uuid";
import Address from "./Address";
import User from "./User";

class Patient extends Model{
    public uuid!: number;
    public firstname!: string;
    public lastname!: string;
    public disease!: string;
    public referedby!: string;
    public referedto!: string;
    public referalstatus!: any;
    public referback!: boolean
    public address!: string;
    public gender!: string;
    public dob!: string;
    public email!: string;
    public phone!: string;
    public laterality!: string;
    public timing!: string;
    public insurance!: string;
    public insurancePlan!: string;
    referedtoUser: any;
    referedbyUser: any;
    Address: any;
    Appointment: any;
    consultNote:any;
    document:any

}

Patient.init({
    uuid:{
        type: DataTypes.UUID,
        defaultValue: UUIDV4,
        primaryKey: true,
        allowNull: false
    },
    dob:{
        type: DataTypes.STRING,
        allowNull: false
    },
    email:{
        type: DataTypes.STRING,
        allowNull: false
    },
    phone:{
        type: DataTypes.STRING,
        allowNull: false
    },
    firstname:{
        type: DataTypes.STRING,
        allowNull: false
    },
    lastname:{
        type: DataTypes.STRING,
        allowNull: false
    },
    disease:{
        type: DataTypes.STRING,
        allowNull: false
    },
    laterality:{
        type: DataTypes.STRING,
        allowNull: false
    },
    referalstatus:{
        type: DataTypes.ENUM('0','1','2','3'),  //0: Rejected , 1: Accepted, 2: Pending , 3: Scheduled
        allowNull: true,
        defaultValue:'2'
    },
    referback:{
        type: DataTypes.BOOLEAN,
        allowNull: false
    },
    gender:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    timing:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    insurance:{
        type: DataTypes.STRING,
        allowNull: true,
    },
    insurancePlan:{
        type: DataTypes.STRING,
        allowNull: true,
    },
    document:{
        type: DataTypes.STRING,
        allowNull: true,
    },
    consultNote:{
        type: DataTypes.STRING,
        allowNull: true,
    },
},{
    sequelize,
    modelName:'Patient'
})

User.hasMany(Patient, { foreignKey: 'referedby',as:'referedbyUser',onDelete: 'CASCADE', onUpdate: 'CASCADE' });
Patient.belongsTo(User, { foreignKey: 'referedby',as:'referedbyUser', onDelete: 'CASCADE', onUpdate: 'CASCADE' });

User.hasMany(Patient, { foreignKey: 'referedto', as:'referedtoUser',onDelete: 'CASCADE', onUpdate: 'CASCADE' });
Patient.belongsTo(User, { foreignKey: 'referedto',as:'referedtoUser', onDelete: 'CASCADE', onUpdate: 'CASCADE' });

Address.hasMany(Patient, {foreignKey:"address" });
Patient.belongsTo(Address, {foreignKey:"address" });

export default Patient;