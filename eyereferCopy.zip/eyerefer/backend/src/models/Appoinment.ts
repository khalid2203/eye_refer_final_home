import { Model, DataTypes } from "sequelize";
import sequelize from "../config/db";
import { v4 as UUIDV4 } from "uuid";
import User from "./User";
import Patient from "./Patient";

class Appointment extends Model {
    public uuid!: string;
    public patientId!: number; 
    public date!: string; 
    public type!: string;
    public userId!: number;
    appointmentDate: any;
    appointmentType: any;
}

Appointment.init({
    uuid: {
        type: DataTypes.UUID,
        defaultValue: UUIDV4,
        primaryKey: true,
        allowNull: false,
    },
    // patientId: {
    //     type: DataTypes.STRING,
    //     allowNull: false,
    // },
    // userId: {
    //     type: DataTypes.STRING,
    //     allowNull: false,
    // },
    appointmentDate: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    appointmentType: {
        type: DataTypes.STRING,
        allowNull: false,
    },
}, {
    sequelize,
    modelName: 'Appointment',
});

User.hasMany(Appointment, { foreignKey: "userId", onDelete: 'CASCADE', onUpdate: 'CASCADE' });
Appointment.belongsTo(User, { foreignKey: "userId", onDelete: 'CASCADE', onUpdate: 'CASCADE' });

Patient.hasMany(Appointment, { foreignKey: "patientId", onDelete: 'CASCADE', onUpdate: 'CASCADE' });
Appointment.belongsTo(Patient, { foreignKey: "patientId", onDelete: 'CASCADE', onUpdate: 'CASCADE' });

export default Appointment;
