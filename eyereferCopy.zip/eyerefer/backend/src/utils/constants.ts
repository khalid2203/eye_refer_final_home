export const httpStatusCodes = {
    ok: 200,
    created:201,
    accepted:202,
    bad_request: 400,
    un_authorized: 401,
    forbidden: 403,
    not_found: 404,
    request_timeout: 408,
    conflict: 409,
    internal_server_error: 500,
}

