import { Local } from "../environment/env";
import Address from "../models/Address";
import Patient from "../models/Patient";
import sendOTP from "../utils/mailer";
import User from "../models/User";
import { Response } from 'express';
import jwt from "jsonwebtoken";
import { Op, Sequelize } from "sequelize";
import bcrypt from 'bcrypt';
import Staff from "../models/Staff";
import Appointment from "../models/Appoinment";
import { log } from "console";
import Notifications from "../models/Notification";
import { httpStatusCodes } from "../utils/constants";
const  CsvParser = require('json2csv').Parser;

const Security_Key: any = Local.SECRET_KEY;

const otpGenerator = () => {
    return String(Math.round(Math.random() * 10000000000)).slice(0, 6);
}

export const registerUser = async (req: any, res: Response) => {
    try {
        const { firstname, lastname, doctype, email, password } = req.body;
        const isExist = await User.findOne({ where: { email: email } });
        if (isExist) {
            res.status(httpStatusCodes.un_authorized).json({ "message": "User already Exist" });
        }
        else {

            const hashedPassword = await bcrypt.hash(password, 10);
            const user = await User.create({ firstname, lastname, doctype, email, password: hashedPassword });
            if (user) {
                const OTP = otpGenerator();
                sendOTP(user.email, OTP);
                res.status(httpStatusCodes.created).json({ "OTP": OTP, "message": "Data Saved Successfully" });
            }
            else {
                res.status(httpStatusCodes.forbidden).json({ "message": "Something Went Wrong" });
            }
        }
    }
    catch (err) {
        res.status(httpStatusCodes.internal_server_error).json({ "message": err });
    }
}

export const verifyUser = async (req: any, res: Response) => {
    try {
        const { email } = req.body;
        const user = await User.findOne({ where: { email } });
        if (user) {
            user.is_verified = true;
            user.save();
            res.status(httpStatusCodes.ok).json({ "message": "User Verfied Successfully" });
        }
        else {
            res.status(httpStatusCodes.forbidden).json({ "message": "Something Went Wrong" })
        }
    }
    catch (err) {
        res.status(httpStatusCodes.internal_server_error).json({ "message": err })
    }
}

export const loginUser = async (req: any, res: Response) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ where: { email } });
        if (user) {
            const isMatch = await bcrypt.compare(password, user.password);
            if (isMatch) {
                if (user.is_verified) {
                    const token = jwt.sign({ uuid: user.uuid }, Security_Key);
                    res.status(httpStatusCodes.ok).json({ "token": token, "user": user, "message": "Login Successfull" });
                }
                else {
                    const OTP = otpGenerator();
                    sendOTP(user.email, OTP);
                    res.status(httpStatusCodes.ok).json({ "user": user, "OTP": OTP, "message": "OTP sent Successfully" });
                }
            }
            else {
                res.status(httpStatusCodes.forbidden).json({ "message": "Invalid Credentials" });
            }
        }
        else {
            res.status(httpStatusCodes.forbidden).json({ "message": "User doesn't Exist" });
        }
    }
    catch (err) {
        res.status(httpStatusCodes.internal_server_error).json({ "message": err });
    }
}

export const getUser = async (req: any, res: Response) => {
    try {
        const { uuid } = req.user;
        const user = await User.findOne({ where: { uuid: uuid }, include: Address });
        if (user) {
            const referCount1 = await Patient.count({
                where: {
                    [Op.or]: [{ referedby: uuid }, { referedto: uuid }]
                }
            });
            const referCompleted = await Patient.count({
                where: {
                  [Op.and]: [
                    {
                      [Op.or]: [
                        { referedby: uuid },
                        { referedto: uuid }
                      ]
                    },
                    { referalstatus: '1' }
                  ]
                }
              });
                          
            let docCount = await User.count({ where: { is_verified: 1 } });
        
            const notificationCount = await Notifications.count({where: {receiverId: uuid, isSeen: false}})
          
            res.status(httpStatusCodes.ok).json({ "user": user, "docCount": docCount, "referCount": referCount1, "referCompleted": referCompleted, "notificationCount": notificationCount });
        }
        else {
            res.status(httpStatusCodes.not_found).json({ "message": "User Not Found" })
        }
    }
    catch (err) {
        res.status(httpStatusCodes.internal_server_error).json({ "message": `Error--->${err}` })
    }
}

export const getDashboardTime = async (req: any, res: Response) => {
    try {
        const { uuid } = req.user;
        const patientTableTime = await Patient.findOne({
            where: {
                [Op.or]: [
                    { referedby: uuid }, 
                    { referedto: uuid }
                ]
            },
            order: [['updatedAt', 'DESC']], 
            attributes: ['updatedAt'],     
        });

        const referCompleted = await Patient.findOne({
            where: {
              [Op.and]: [
                {
                  [Op.or]: [
                    { referedby: uuid },
                    { referedto: uuid }
                  ]
                },
                { referalstatus: '1' }
              ]
            },
            order: [['updatedAt', 'DESC']],
            attributes: ['updatedAt'], 
          });

        const userTableTime = await User.findOne({
            order: [['updatedAt', 'DESC']],
            attributes: ['updatedAt'], 
        });

        res.status(httpStatusCodes.ok).json({
            patientTableTime,
            referCompleted,
            userTableTime,
        });
    } catch (err:any) {
        res.status(httpStatusCodes.internal_server_error).json({ "message": err.message || 'Internal server error' });
    }
};

export const getDocList = async (req: any, res: Response) => {
    try {
        const { uuid } = req.user;
        const user = await User.findOne({ where: { uuid: uuid } })
        let docList;
        if (user?.doctype == 1) {
            docList = await User.findAll({ where: { uuid: { [Op.ne]: uuid } }, include: Address });
        }
        else {
            docList = await User.findAll({ where: { doctype: 1, uuid: { [Op.ne]: uuid } }, include: Address });
        }
        if (docList) {
            res.status(httpStatusCodes.ok).json({ "docList": docList, "message": "Docs List Found" });
        }
        else {
            res.status(httpStatusCodes.not_found).json({ "message": "MD List Not Found" });
        }
    }
    catch (err) {
        res.status(httpStatusCodes.internal_server_error).json({ "message": `${err}` });
    }

}


export const getPatientList = async (req: any, res: Response) => {
    try {
        const { uuid } = req.user;
        const user = await User.findOne({ where: { uuid: uuid } });

        if (user) {
            const page: number = parseInt(req.query.page as string) || 1;
            const limit: number = parseInt(req.query.limit as string) || 100 ; 
            const search: string = req.query.search as string || '';

            const offset: number = (page - 1) * limit;
            const order: string = req.query.order

            const searchCondition = search ? {
                [Op.or]: [
                    { firstname: { [Op.like]: `%${search}%` } },
                    { lastname: { [Op.like]: `%${search}%` } },
                    { disease: { [Op.like]: `%${search}%` } }
                ]
            } : {};

            const { count, rows } = await Patient.findAndCountAll({
                where: {
                    [Op.or]: [{ referedby: uuid }, { referedto: uuid }],
                    ...searchCondition 
                },
                include: [
                    {
                        model: User,
                        as: 'referedtoUser',
                        attributes: ['uuid','firstname', 'lastname'],
                    },
                    {
                        model: User,
                        as: 'referedbyUser',
                        attributes: ['uuid','firstname', 'lastname'],
                    },
                    {
                        model: Address,
                        attributes: ['street','city', 'state', 'pincode'],
                    }
                ],
                limit,
                offset,
                order: [['createdAt', order]],
            });

            const totalPages = Math.ceil(count / limit);

            const patientList = rows.map((patient: any) => ({
                uuid: patient.uuid,
                firstname: patient.firstname,
                lastname: patient.lastname,
                disease: patient.disease,
                dob: patient.dob,
                referalstatus: patient.referalstatus,
                referback: patient.referback,
                createdAt: patient.createdAt,
                updatedAt: patient.updatedAt,
                referedto: patient.referedtoUser,
                referedby: patient.referedbyUser,
                address: patient.Address
            }));

            res.status(httpStatusCodes.ok).json({
                patientList,
                pagination: {
                    currentPage: page,
                    totalPages,
                    totalItems: count,
                },
                message: 'Patient List Found',
            });
        } else {
            res.status(httpStatusCodes.not_found).json({ message: 'User Not Found' });
        }
    } catch (err) {
        res.status(httpStatusCodes.internal_server_error).json({ message: `${err}` });
    }
};

export const getPatientDetails = async (req: any, res: Response) => {
    try {
        const patientId = req.params.patientId;

        const patient = await Patient.findOne({
            where: { uuid: patientId },
            include: [
                {
                    model: User,
                    as: 'referedtoUser',
                    attributes: ['firstname', 'lastname'],
                },
                {
                    model: User,
                    as: 'referedbyUser',
                    attributes: ['firstname', 'lastname'],
                },
                {
                    model: Address,
                    attributes: ['street', 'city', 'state', 'pincode'],
                }
            ]
        });

        const appoinment = await Appointment.findOne({where: {patientId}})
        

        if (patient) {
            // Construct the response object
            const patientDetails = {
                uuid: patient.uuid,
                firstname: patient.firstname,
                lastname: patient.lastname,
                gender: patient.gender,
                dob: patient.dob,
                email: patient.email,
                phone: patient.phone,
                laterality: patient.laterality,
                insurance: patient.insurance,
                insurancePlan: patient.insurancePlan,
                timing: patient.timing,
                disease: patient.disease,
                referalstatus: patient.referalstatus,
                referback: patient.referback,
                notes: patient.consultNote,
                document: patient.document,
                // createdAt: patient.createdAt,
                // updatedAt: patient.updatedAt,
                referedto: patient.referedtoUser,
                referedby: patient.referedbyUser,
                address: patient.Address,
                appointment: appoinment
            };

            res.status(httpStatusCodes.ok).json({
                patientDetails,
                message: 'Patient Details Found',
            });
        } else {
            res.status(httpStatusCodes.not_found).json({ message: 'Patient Not Found' });
        }
    } catch (err) {
        res.status(httpStatusCodes.internal_server_error).json({ message: `${err}` });
    }
};


export const addPatient = async (req: any, res: Response) => {
    try {

        const { uuid } = req.user;
        const user = await User.findOne({ where: { uuid: uuid } });
        if (user) {
            const { gender,timing, dob,email,phone,consultNote, laterality,insurance,insurancePlan,firstname, lastname, disease, address, referedto, referback } = req.body;
            const docPath = req.file ? req.file.path : null;
            // console.log("docPath------------", req.file);
            
            const patient = await Patient.create({ consultNote, document: docPath,gender,timing, dob,email,phone,laterality,insurance,insurancePlan,firstname, lastname, disease, address, referedto, referback, referedby: uuid });
            if (patient) {
                res.status(httpStatusCodes.ok).json({ "message": "Patient added Successfully" });
            }
        }
        else {
            res.status(httpStatusCodes.un_authorized).json({ "message": "you're not Authorised" });
        }
    }
    catch (err) {
        console.log(err);
        
        res.status(httpStatusCodes.internal_server_error).json({ "message": `${err}` });
    }
}



export const updatePatientDetails = async (req: any, res: any) => {
    try {
        const patientId = req.params.patientId;

        const { gender, dob, email, phone, laterality, insurance, insurancePlan, firstname, lastname, disease , consultNote} = req.body;

        const patient = await Patient.findOne({ where: { uuid: patientId } });

        if (!patient) {
            return res.status(httpStatusCodes.not_found).json({ message: "Appointment not found" });
        }
        const docPath = req.file ? req.file.path : null;
        console.log("docpathttttt", req.file);
        
        patient.gender = gender || patient.gender;
        // patient.timing = timing || patient.timing;
        patient.dob = dob || patient.dob;
        patient.email = email || patient.email;
        patient.phone = phone || patient.phone;
        patient.laterality = laterality || patient.laterality;
        patient.insurance = insurance || patient.insurance;
        patient.insurancePlan = insurancePlan || patient.insurancePlan;
        patient.firstname = firstname || patient.firstname;
        patient.lastname = lastname || patient.lastname;
        patient.disease = disease || patient.disease;
        patient.consultNote = consultNote || patient.consultNote;
        patient.document = docPath || patient.document;
        // patient.address = address || patient.address;
        // patient.referedto = referredTo || patient.referedto;
        // patient.referback = referBack || patient.referback;

        await patient.save();

        return res.status(httpStatusCodes.ok).json({ message: "Profile updated successfully" });
    } catch (error) {
        console.error(error);
        return res.status(httpStatusCodes.internal_server_error).json({ message: "Error updating profile" });
    }
};


export const deletePatient = async(req:any, res: Response) =>{
    try{
        const {uuid} = req.user
        const {patientId} = req.params
        const patient = await Patient.findOne({where: {uuid: patientId, referedby: uuid}})
        if(patient){
            await patient.destroy()
            res.status(httpStatusCodes.ok).json({ message: "Patient deleted successfully" });
        } else {
            res.status(httpStatusCodes.not_found).json({ message: "Patient not found" });
        }
    } catch (err:any) {
        res.status(httpStatusCodes.internal_server_error).json({ message: `Error: ${err.message}` });
    }
};


export const addAddress = async (req: any, res: Response) => {
    try {
        const { uuid } = req.user;
        const user = await User.findOne({ where: { uuid: uuid } });
        if (user) {
            const { street, district, city, state, pincode, phone } = req.body;
            const address = await Address.create({ street, district, city, state, pincode, phone, user: uuid });
            if (address) {
                res.status(httpStatusCodes.ok).json({ "message": "Address added Successfully" });
            }
            else {
                res.status(httpStatusCodes.bad_request).json({ "message": "Error in Saving Address" });
            }
        }
        else {
            res.status(httpStatusCodes.un_authorized).json({ "message": "you are not Authorised"});
        }
    }
    catch (err) {
        res.status(httpStatusCodes.internal_server_error).json({ "message": `${err}` });
    }
}

export const deleteAddress = async (req: any, res: Response) => {
    try {
        const { uuid } = req.user;
        const { addressId } = req.params; 
           
        const address = await Address.findOne({ where: { uuid: addressId, user: uuid } });
   
        if (address) {
            await address.destroy();
            res.status(httpStatusCodes.ok).json({ message: "Address deleted successfully" });
        } else {
            res.status(httpStatusCodes.not_found).json({ message: "Address not found" });
        }
    } catch (err:any) {
        res.status(httpStatusCodes.internal_server_error).json({ message: `Error: ${err.message}` });
    }
};

export const getDoctorList = async (req: any, res: Response) => {
    try {
        const { uuid } = req.user;

        const page: number = parseInt(req.query.page as string) || 1;
        const limit: number = parseInt(req.query.limit as string) || 4;
        const search: string = req.query.search as string || '';
        const offset: number = (page - 1) * limit;
        
        const order: string = req.query.order;

        const searchCondition = search
            ? {
                  [Op.or]: [
                      { firstname: { [Op.like]: `%${search}%` } },
                      { lastname: { [Op.like]: `%${search}%` } },
                      { email: { [Op.like]: `%${search}%` } },
                      { phone: { [Op.like]: `%${search}%` } },
                      { gender: { [Op.like]: `%${search}%` } },
                  ],
              }
            : {};

        const user = await User.findOne({ where: { uuid: uuid }, include: Address });

        if (user) {
            const referCount = await Patient.count({ where: { referedto: uuid } });
            const referCompleted = await Patient.count({ where: { referedto: uuid, referalstatus: 1 } });

            const docCount = await User.count({
                where: {
                    is_verified: 1,
                    doctype: [1, 2],
                }
            });

            const doctorList = await User.findAndCountAll({
                where: {
                    doctype: [1, 2],
                    is_verified: 1,  
                    ...searchCondition,
                },
                include: Address,
                limit,  
                offset, 
                order: [['createdAt', order]], 
            });

            const pagination = {
                currentPage: page,
                totalPages: Math.ceil(doctorList.count / limit),
                totalItems: doctorList.count,
            };

            res.status(httpStatusCodes.ok).json({
                user,
                message: "User Found",
                docCount,
                referCount,
                referCompleted,
                doctorList: doctorList.rows, 
                pagination,
            });
        } else {
            res.status(httpStatusCodes.not_found).json({ message: "User Not Found" });
        }
    } catch (err) {
        console.error("Error fetching doctor list:", err);
        res.status(httpStatusCodes.internal_server_error).json({ message: `Error: ${err}` });
    }
};



export const getUserProfile = async (req: any, res: Response) => {
    try {
        const { uuid } = req.user;
        const user = await User.findOne(
            { where: { uuid: uuid },
             include:[ 
                {model:Address,
                    order: [['createdAt', 'DESC']],
                },
                
            ],
        });
        
        if (!user) {
            return res.status(httpStatusCodes.not_found).json({ "message": "User Not Found" });
        }

        let profileDetails: any = {
            user: user,
            message: "User Found",
        };

        if (user.doctype === 1) {
            const patientCount = await Patient.count({ where: { referedto: uuid } });
            const referredPatients = await Patient.findAll({ where: { referedto: uuid } });
            profileDetails = {
                ...profileDetails,
                patientCount: patientCount,
                referredPatients: referredPatients,
            };
        } else if (user.doctype === 2) { 
            const referredDoctors = await User.findAll({ where: { uuid: { [Op.in]: user.referredby } }, include: Address });
            profileDetails = {
                ...profileDetails,
                referredDoctors: referredDoctors,
            };
        } else {
            
            profileDetails = {
                ...profileDetails,
                additionalData: "Custom data for Admin or other types"
            };
        }

        res.status(httpStatusCodes.ok).json(profileDetails);
    } catch (err) {
        res.status(httpStatusCodes.internal_server_error).json({ "message": `Error--->${err}` });
    }
};

export const updateprofile = async (req: any, res: any) => {
    try {
        const { uuid } = req.user;
        const { firstname, lastname, phone, gender } = req.body;

        const user = await User.findOne({ where: { uuid: uuid } });
        if (!user) {
            return res.status(httpStatusCodes.not_found).json({ message: "User not found" });
        }

        user.firstname = firstname || user.firstname;
        user.lastname = lastname || user.lastname;
        user.phone = phone || user.phone;
        user.gender = gender || user.gender;

        await user.save();

        return res.status(httpStatusCodes.ok).json({ message: "Profile updated successfully" });
    } catch (error) {
        console.error(error);
        return res.status(httpStatusCodes.internal_server_error).json({ message: "Error updating profile" });
    }
};

export const updateProfileImage = async (req: any, res: any) => {
    try {
        const { uuid } = req.user;
        
        const imgPath = req.file ? req.file.path : null;

        const user = await User.findOne({ where: { uuid: uuid } });
        if (!user) {
            return res.status(httpStatusCodes.not_found).json({ message: "User not found" });
        }

        user.profile_photo = imgPath || user.profile_photo;
        await user.save();

        return res.status(httpStatusCodes.ok).json({ profile_photo: user.profile_photo, message: "Profile image updated successfully" });
    } catch (error) {
        console.error(error);
        return res.status(httpStatusCodes.internal_server_error).json({ message: "Error updating profile image" });
    }
};


export const changePassword = async (req: any, res: any) => {
    try {
        const { uuid } = req.user;
        const { currentPassword, newPassword } = req.body;

    
        const user = await User.findOne({ where: { uuid } });

        if (!user) {
            return res.status(httpStatusCodes.not_found).json({ "message": "User not found" });
        }

        const isMatch = await bcrypt.compare(currentPassword, user.password);

        if (!isMatch) {
            return res.status(httpStatusCodes.forbidden).json({ "message": "Current password is incorrect" });
        }

        const hashedPassword = await bcrypt.hash(newPassword, 10);

        user.password = hashedPassword;
        await user.save();
        return res.status(httpStatusCodes.ok).json({ "message": "Password updated successfully" });
    } catch (err) {
        console.error(err);
        return res.status(httpStatusCodes.internal_server_error).json({ "message": "Error updating password" });
    }
};

export const addStaff = async (req: any, res: Response):Promise<void> => {
    try {
        const { uuid } = req.user;

        const user = await User.findOne({ where: { uuid: uuid } });

        if (user) {
            const { firstname, lastname, gender, email, phoneNumber } = req.body;

            if (!firstname || !lastname || !gender || !email || !phoneNumber) {
                 res.status(httpStatusCodes.bad_request).json({ message: 'All fields are required' });
                 return
            }

            const staff = await Staff.create({
                firstname,
                lastname,
                gender,
                email,
                phoneNumber,
                userId: uuid,
            });

            if (staff) {
                 res.status(httpStatusCodes.ok).json({ message: 'Staff added successfully' });
                 return
            } else {
                 res.status(httpStatusCodes.bad_request).json({ message: 'Error in saving staff' });
                 return
            }
        } else {
             res.status(httpStatusCodes.un_authorized).json({ message: "You're not authorized" });
             return
        }
    } catch (err) {
        console.error(err);
         res.status(httpStatusCodes.internal_server_error).json({ message: 'Server error, please try again later' });
         return
    }
};


export const getStaffList = async (req: any, res: Response): Promise<void> => {
    try {
        const { uuid } = req.user;

        const page: number = parseInt(req.query.page as string) || 1; 
        const limit: number = parseInt(req.query.limit as string) || 4; 
        const search: string = req.query.search as string || '';
        const offset: number = (page - 1) * limit;

        const order : string = req.query.order

        const searchCondition = search
            ? {
                  [Op.or]: [
                      { firstname: { [Op.like]: `%${search}%` } },
                      { lastname: { [Op.like]: `%${search}%` } },
                      { email: { [Op.like]: `%${search}%` } },
                      { phoneNumber: { [Op.like]: `%${search}%` } },
                  ],
              }
            : {};

        const staffList = await Staff.findAndCountAll({
            where: {
                userId: uuid,
                ...searchCondition,
            },
            attributes: ['uuid', 'firstname', 'lastname', 'gender', 'email', 'phoneNumber'],
            order: [['createdAt', order]], 
            limit, 
            offset, 
        });


        const pagination = {
            currentPage: page,
            totalPages: Math.ceil(staffList.count / limit),
            totalItems: staffList.count,
        };

        res.status(httpStatusCodes.ok).json({
            data: staffList.rows,
            pagination,
        });
    } catch (err) {
        console.error(err);
        res.status(httpStatusCodes.internal_server_error).json({ message: 'Server error, please try again later.' });
    }
};

export const addAppointment = async (req: any, res: any): Promise<void> => {
    try {
      const { uuid } = req.user; 
      const user = await User.findOne({ where: { uuid } });
  
      if (!user) {
        res.status(httpStatusCodes.not_found).json({ message: 'User not found' });
        return;
      }
  
      const { appointmentDate, patientId, appointmentType } = req.body;
  
      if (!appointmentDate || !patientId || !appointmentType) {
        res.status(httpStatusCodes.bad_request).json({ message: 'Missing required fields' });
        return;
      }
  
      const appointment = await Appointment.create({
        appointmentDate,
        patientId,
        appointmentType,
        userId: uuid,
      });

      const patient = await Patient.findOne({ where: { uuid: patientId } });
    //   console.log("patien referedby------------------->", patient?.referedby);
    const referedById = patient?.referedby;
    const patientName = patient?.firstname+ " " + patient?.lastname;
    
    if(patient){
        patient.referalstatus = '3';

        await patient.save();
    }
  
      if (appointment) {
          res.status(httpStatusCodes.created).json({
              appointment,
              referedById,
              patientName
          });
      } else {
          res.status(httpStatusCodes.internal_server_error).json({ message: 'Error creating appointment' });
      }
    } catch (err) {
      console.error(err);
      res.status(httpStatusCodes.internal_server_error).json({ message: 'Server error' });
    }
  };
  

export const getAppointments = async (req: any, res: Response): Promise<void> => {
    try {
        const { uuid: userId } = req.user;
        // ----------------------------
        const page: number = parseInt(req.query.page as string) || 1;
        const limit: number = parseInt(req.query.limit as string) || 10;
        const search: string = req.query.search as string || '';
        
        const offset: number = (page - 1) * limit;
        const order : string = req.query.order
    
        const whereCondition: any = {
          userId: userId,
        };
    
        if (search) {
          whereCondition[Op.or] = [
            {
              '$Patient.firstname$': {
                [Op.like]: `%${search}%`,
              },
            },
            {
              '$Appointment.appointmentDate$': {
                [Op.like]: `%${search}%`,
              },
            },
            {
              '$Appointment.appointmentType$': {
                [Op.like]: `%${search}%`,
              },
            },
            {
              '$Patient.lastname$': {
                [Op.like]: `%${search}%`,
              },
            },
            {
              '$Patient.email$': {
                [Op.like]: `%${search}%`,
              },
            },
            {
              '$Patient.phone$': {
                [Op.like]: `%${search}%`,
              },
            },
  
          ];
        }
        // ----------------------------

        const {count,rows} = await Appointment.findAndCountAll({
            // where: {
            //     userId: userId, 
            // },
            where: whereCondition,
            attributes: ['uuid', 'appointmentDate', 'appointmentType'],
            include: [
                {
                    model: Patient,
                    attributes: ['uuid', 'firstname', 'lastname', 'disease','referalstatus'], 
                },
                {
                    model: User,
                    attributes: ['uuid', 'firstname', 'lastname', 'email'],
                },
            ],
            order: [['createdAt', order]],
            limit,
            offset,
        });

        const totalPages = Math.ceil(count / limit);

        const pagination = {
            currentPage: page,
            totalPages,
            totalItems:count,
        };
        res.status(httpStatusCodes.ok).json({
         data:rows,
        pagination
      });

    } catch (err) {
        console.error(err);
        res.status(httpStatusCodes.internal_server_error).json({ message: 'Server error, please try again later.' });
    }
};



export const deleteAppoinment = async (req: any, res: Response) => {
    try {
        const { uuid } = req.user;
        const { appointmentId } = req.params; 
        
        const appoinment = await Appointment.findOne({ where: { uuid: appointmentId, userId: uuid } });

        if (appoinment) {
            await appoinment.destroy();
            res.status(httpStatusCodes.ok).json({ message: "Appoinment deleted successfully" });
        } else {
            res.status(httpStatusCodes.not_found).json({ message: "Appoinment not found" });
        }
    } catch (err:any) {
        res.status(httpStatusCodes.internal_server_error).json({ message: `Error: ${err.message}` });
    }
};


export const deleteStaff = async (req: any, res: Response) => {
    try {
        const { uuid } = req.user;
        const { staffId } = req.params; 
        
        const staff = await Staff.findOne({ where: { uuid: staffId, userId: uuid } });

        if (staff) {
            await staff.destroy();
            res.status(httpStatusCodes.ok).json({ message: "Appoinment deleted successfully" });
        } else {
            res.status(httpStatusCodes.not_found).json({ message: "Appoinment not found" });
        }
    } catch (err:any) {
        res.status(httpStatusCodes.internal_server_error).json({ message: `Error: ${err.message}` });
    }
};



export const getAppointmentDetails = async (req: any, res: Response) => {
    try {
        const appointmentId = req.params.appointmentId;

        const appoinmentDetails = await Appointment.findOne({
            where: { uuid: appointmentId }
        });

        const patient = await Patient.findOne({where: {uuid: appoinmentDetails?.patientId},attributes: ['uuid','firstname', 'lastname'], })
        
            res.status(httpStatusCodes.ok).json({
                appoinmentDetails,
                patient,
                message: 'Appointment Details Found',
            });
        } 
     catch (err) {
        res.status(httpStatusCodes.internal_server_error).json({ message: `${err}` });
     }
}


export const updateAppointment = async (req: any, res: any) => {
    try {
        const { uuid } = req.user;
        const appointmentId = req.params.appointmentId;
        const { appointmentDate, appointmentType} = req.body;

        const appoinment = await Appointment.findOne({ where: { uuid:appointmentId } });
        if (!appoinment) {
            return res.status(httpStatusCodes.not_found).json({ message: "Appointment not found" });
        }

        appoinment.appointmentDate = appointmentDate || appoinment.appointmentDate;
        appoinment.appointmentType = appointmentType || appoinment.appointmentType;

        await appoinment.save();

        return res.status(httpStatusCodes.ok).json({ message: "Appointment updated successfully" });
    } catch (error) {
        console.error(error);
        return res.status(httpStatusCodes.internal_server_error).json({ message: "Error updating profile" });
    }
};


export const updatePatientStatus = async (req: any, res: any) => {
    try {
        const {patientId,referalstatus} = req.body;
        // console.log("PatientIDDDDDDDDDDDDDDDDdd",referalstatus);
        

        const patient = await Patient.findOne({ where: { uuid:patientId } });
        if (!patient) {
            return res.status(httpStatusCodes.not_found).json({ message: "Appointment not found" });
        }

        patient.referalstatus = referalstatus;

        await patient.save();

        return res.status(httpStatusCodes.ok).json({ message: "Status updated successfully" });
    } catch (error) {
        console.error(error);
        return res.status(httpStatusCodes.internal_server_error).json({ message: "Error updating status" });
    }
};


export const  downloadStaff = async (req: any, res: Response): Promise<void> => {
    const staff: any = [];
    const { uuid } = req.user;

    try {
        const staffList = await Staff.findAll({where:{userId:uuid}});
        staffList.forEach((item) => {
            const {firstname, lastname, gender, email, phoneNumber} = item;
            staff.push({firstname, lastname, gender, email, phoneNumber});
        })
        const csvFields = ['firstname', 'lastname', 'gender', 'email', 'phoneNumber'];

        const csvParser = new CsvParser({csvFields});
        const csvData = csvParser.parse(staff)
        // console.log(csvData);
        console.log("staflist",staff);
        

        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", "attatchment: filename=stafflist.csv");
        res.status(httpStatusCodes.ok).send(csvData);
    }catch(err){
        console.error(err);
        res.status(httpStatusCodes.internal_server_error).json({ message: 'Server error, please try again later.'});
    }
}
