import { Request, Response } from 'express';
import ChatMessages from '../models/ChatMessage';
import ChatRooms from '../models/ChatRoom';
import { Op } from 'sequelize';
import User from '../models/User';
import Patient from '../models/Patient';
import { httpStatusCodes } from '../utils/constants';

export const getOrCreateChatRoom = async (req: Request, res: Response): Promise<void> => {
    const { referedById, referedToId,patientId, roomId } = req.body;
    try {
        let chatRoom = await ChatRooms.findOne({
            where: {
                referedById,
                referedToId,
                patientId,
            }
        });
        if (!chatRoom) {
            chatRoom = await ChatRooms.create({ referedById, referedToId ,patientId,roomId});
        }
        res.status(httpStatusCodes.ok).json(chatRoom); 
    } catch (error) {
        console.error('Error getting or creating chat room:', error);
        res.status(httpStatusCodes.internal_server_error).json({ error: 'Internal server error' });
    }
  };
  
  
  export const sendMessage = async (req: Request, res: Response): Promise<void> => {
    const { chatRoomId, senderId, message } = req.body;
  
    try {
      const chatRoomExists = await ChatRooms.findOne({
        where: { roomId: chatRoomId }, 
      });
  
      if (!chatRoomExists) {
        res.status(httpStatusCodes.not_found).json({ error: 'Chat room not found' });
        return;
      }
  
      const chatMessage = await ChatMessages.create({ chatRoomId, senderId, message });
  
      res.status(httpStatusCodes.created).json(chatMessage);
    } catch (error) {
      console.error('Error sending message:', error);
      res.status(httpStatusCodes.internal_server_error).json({ error: 'Internal server error' });
    }
  };
  

  export const getChatHistory = async (req: Request, res: Response): Promise<void> => {
    const { chatRoomId } = req.params;
  
    try {
      const messages = await ChatMessages.findAll({
        where: { chatRoomId },
        // order: [['createdAt', 'ASC']],
      });
  
      const messagesWithUserDetails = await Promise.all(messages.map(async (message) => {
        const user = await User.findOne({ where: { uuid: message.senderId } });
  
        return {
          ...message.toJSON(),
          senderFirstName: user?.firstname,
          senderLastName: user?.lastname
        };
      }));
  
      res.status(httpStatusCodes.ok).json(messagesWithUserDetails);
  
    } catch (error) {
      console.error('Error fetching chat history:', error);
      res.status(httpStatusCodes.internal_server_error).json({ error: 'Internal server error' });
    }
  };
  


export const getUserChatRooms = async (req: any, res: Response): Promise<void> => {
    try {
        const { uuid } = req.user;
        let doctor_name;
        let profile_photo;
//   console.log("loggggggedddinuser",uuid);
  
      const chatRooms = await ChatRooms.findAll({
        where: {
          [Op.or]: [
            { referedById: uuid },
            { referedToId: uuid }
          ]
        },
        order: [['createdAt', 'DESC']]
      });

      const chatroomWithUserDetails = await Promise.all(chatRooms.map(async (rooms) => {
        const patient = await Patient.findOne({ where: { uuid: rooms.patientId } });
        const user1 = await User.findOne({ where: { uuid: rooms.referedById }})
        const user2 = await User.findOne({ where: { uuid: rooms.referedToId}})
        const user1Name= user1?.firstname + " " + user1?.lastname
        const user1Photo = user1?.profile_photo;
        const user2Photo = user2?.profile_photo;
        const user2Name= user2?.firstname + " " + user2?.lastname
        if(uuid === rooms.referedById){
          doctor_name = user2Name
          profile_photo = user2Photo
       }else{
        doctor_name = user1Name
        profile_photo = user1Photo
       }
  
        return {
          ...rooms.toJSON(),
          patientFirstName: patient?.firstname,
          patientLastName: patient?.lastname,
          doctor_name,
          profile_photo
        };
      }));

      // if (!chatRooms || chatRooms.length === 0) {
      //    res.status(httpStatusCodes.not_found).json({ message: 'No chat rooms found for this user' });
      //    return  
      // }
  
      res.status(httpStatusCodes.ok).json(chatroomWithUserDetails);
    } catch (error) {
      console.error('Error fetching chat rooms:', error);
      res.status(httpStatusCodes.internal_server_error).json({ error: 'Internal server error' });
    }
  };