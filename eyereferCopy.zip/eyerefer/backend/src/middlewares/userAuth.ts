import jwt from 'jsonwebtoken';
import { NextFunction } from 'express';
import { Local } from '../environment/env';
import { httpStatusCodes } from '../utils/constants';

const Secret: any = Local.SECRET_KEY;

const userAuthMiddleware = async (req: any, res: any, next: NextFunction) => {
    const token = req.header('Authorization')?.split(' ')[1];
    // console.log("token", token)
    if (!token) {
        return res.status(httpStatusCodes.forbidden);
    }

    jwt.verify(token, Secret, (err: any, uuid: any) => {
        if (err) {
            return res.status(httpStatusCodes.un_authorized).json({ "message": err });
        }

        req.user = uuid;
        next();
    });
};

export default userAuthMiddleware;
