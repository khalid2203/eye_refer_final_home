import Joi from "joi"
import { httpStatusCodes } from "../../utils/constants"
export const validatePatient =(req:any,res:any,next:any)=>{
    const validatePatientSchema=Joi.object({
        firstname:Joi.string().required(),
        lastname:Joi.string().required(),
        dob:Joi.string().required(),
        email:Joi.string().email().required(),
        phone:Joi.string().min(10).required(),
        disease:Joi.string().required(),
        laterality:Joi.string().required(),
        referalstatus:Joi.string(),
        referback:Joi.string().required(),
        gender:Joi.string().required(),
        timing:Joi.string().required(),
        insurance:Joi.string().optional().allow(""),
        insurancePlan:Joi.string().optional().allow(""),
        document:Joi.string().optional().allow(""),
        consultNote:Joi.string().optional().allow(""),
        referedto: Joi.string().required(),
        // referedby: Joi.string().required(),
        address: Joi.string().required(),
    })
    const {error}=validatePatientSchema.validate(req.body)
    if(error){
        const msg = error.details.map(el=>el.message).join(',')
        return res.status(httpStatusCodes.conflict).json({message:msg})
    }
    next()
}