import Joi from "joi"
import { httpStatusCodes } from "../../utils/constants"
export const validateAppointment =(req:any,res:any,next:any)=>{
    const validateAppointmentSchema=Joi.object({
        appointmentDate:Joi.string().required(),
        appointmentType:Joi.string().required(),
        patientId:Joi.string().required(),
    })
    const {error}=validateAppointmentSchema.validate(req.body)
    if(error){
        const msg = error.details.map(el=>el.message).join(',')
        return res.status(httpStatusCodes.conflict).json({message:msg})
    }
    next()
}