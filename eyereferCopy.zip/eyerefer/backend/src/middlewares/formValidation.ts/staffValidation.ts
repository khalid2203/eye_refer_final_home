import Joi from "joi"
import { httpStatusCodes } from "../../utils/constants"
export const validateStaff =(req:any,res:any,next:any)=>{
    const validateStaffSchema=Joi.object({
        firstname:Joi.string().required(),
        lastname:Joi.string().required(),
        email:Joi.string().email().required(),
        phoneNumber:Joi.string().min(10).required(),
        gender:Joi.string().required(),
    })
    const {error}=validateStaffSchema.validate(req.body)
    if(error){
        const msg = error.details.map(el=>el.message).join(',')
        return res.status(httpStatusCodes.conflict).json({message:msg})
    }
    next()
}