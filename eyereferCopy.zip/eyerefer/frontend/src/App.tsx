import React from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Dashboard from './components/Dashboard';
import PatientList from './components/PatientList';
import AddPatient from './components/AddPatient';
import DoctorList from './components/DoctorList';
import StaffList from './components/StaffList';
import Signup from './components/Signup';
import Header from './components/Header';
import Verify from './components/Verify';
import Login from './components/Login';
import Profile from './components/Profile';
import AddAddress from './components/AddAddress';
import Chat from './components/Chat';
import './App.css';
import UpdatePassword from './components/UpdatePassword';
import AddAppoinment from './components/AddAppoinment';
import Appoinments from './components/Appoinments';
import PatientDetails from './components/PatientDetails';
import AppointmentDetails from './components/AppointmentDetails';
import UpdateAppointment from './components/UpdateAppointment';
import UpdatePatient from './components/UpdatePatient';
import Graph from './components/graph/Graph';
import Notifiactions from './components/Notifiactions';
import { UserProvider } from './components/context/UserContext';

const App: React.FC = () => {
  const router = createBrowserRouter([
    { path: '/', element: <Signup /> },
    { path: '/Verify', element: <Verify /> },
    { path: '/login', element: <Login /> },
    {
      path: '/',
      element: <UserProvider><Header /></UserProvider>,
      children: [
        { path: '/dashboard', element: <UserProvider><Dashboard /></UserProvider> },
        { path: '/patient', element: <PatientList /> },
        { path: '/patient-details/:patientId', element: <PatientDetails /> },
        { path: '/update-patient/:patientId', element: <UpdatePatient /> },
        { path: '/appointment-details/:appointmentId', element: <AppointmentDetails /> },
        { path: '/update-appointment/:appointmentId', element: <UpdateAppointment /> },
        { path: '/add-patient', element: <AddPatient /> },
        { path: '/doctor', element: <DoctorList /> },
        { path: '/staff', element: <StaffList /> },
        {
          path: '/add-address', element: <AddAddress close={function (): void {
            throw new Error('Function not implemented.');
          }} />
        },
        { path: '/profile', element: <UserProvider><Profile /></UserProvider> },
        { path: '/chat', element: <Chat /> },
        { path: '/appointments', element: <Appoinments /> },
        { path: '/add-appointment', element: <AddAppoinment /> },
        { path: '/update-password', element: <UpdatePassword /> },
        { path: '/graph', element: <Graph /> },
        { path: '/notifications', element: <Notifiactions /> },
      ]
    }
  ]);

  return (
    <>
      <RouterProvider router={router} />
      <ToastContainer newestOnTop={false} closeOnClick />
    </>
  );
};

export default App;
