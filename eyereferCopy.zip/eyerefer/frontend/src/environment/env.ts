/* eslint-disable @typescript-eslint/no-explicit-any */
interface config {
    GET_DASHBOARD_TIME: any;
    MARK_READ: any;
    DELETE_PATIENT: any;
    GET_NOTIFICATIONS: any;
    DELETE_NOTIFICATION: any;
    UPDATE_PROFILE_IMAGE: any;
    DOWNLOAD_STAFFLIST: any;
    DELETE_STAFF: any;
    UPDATE_APPOINTMENT: any;
    VIEW_APPOINTMENT: any;
    VITE_CHANGE_PASSWORD: any;
    GET_DOCTOR_LIST: any;
    CREATE_APPOINTMENT: any;
    GET_PATIENT_APPOINTMENTS: any;
    BASE_URL: string;
    CREATE_USER: string;
    VERIFY_USER: string;
    LOGIN_USER: string;
    GET_USER: string;
    GET_DOC_LIST: string;
    GET_PATIENT_LIST: string;
    GET_PATIENT_DETAILS: string;
    UPDATE_PATIENT_DETAILS: string;
    UPDATE_PATIENT_STATUS: string;
    ADD_PATIENT: string;
    ADD_ADDRESS: string;
    DELETE_ADDRESS: string;
    ADD_APPOINTMENT: string;
    DELETE_APPOINTMENT: string;
    GET_APPOINTMENT: string;
    ADD_STAFF: string;
    GET_STAFF: string;
    UPDATE_USER:string;
    CHANGE_PASSWORD:string;
}

export const Local: config = {
    BASE_URL: import.meta.env.VITE_BASE_URL,
    CREATE_USER: import.meta.env.VITE_CREATE_USER,
    VERIFY_USER: import.meta.env.VITE_VERIFY_USER,
    LOGIN_USER: import.meta.env.VITE_LOGIN_USER,
    GET_USER: import.meta.env.VITE_GET_USER,
    GET_DOC_LIST: import.meta.env.VITE_GET_DOC_LIST,
    GET_PATIENT_LIST: import.meta.env.VITE_GET_PATIENT_LIST,
    GET_PATIENT_DETAILS: import.meta.env.VITE_GET_PATIENT_DETAILS,
    UPDATE_PATIENT_DETAILS: import.meta.env.VITE_UPDATE_PATIENT_DETAILS,
    UPDATE_PATIENT_STATUS: import.meta.env.VITE_UPDATE_PATIENT_STATUS,
    ADD_PATIENT: import.meta.env.VITE_ADD_PATIENT,  
    ADD_ADDRESS: import.meta.env.VITE_ADD_ADDRESS,
    DELETE_ADDRESS: import.meta.env.VITE_DELETE_ADDRESS,
    DELETE_PATIENT: import.meta.env.VITE_DELETE_PATIENT,
    ADD_STAFF: import.meta.env.VITE_ADD_STAFF, //ADD STAFF
    ADD_APPOINTMENT: import.meta.env.VITE_ADD_APPOINTMENT,
    GET_APPOINTMENT: import.meta.env.VITE_GET_APPOINTMENT,
    VIEW_APPOINTMENT: import.meta.env.VITE_VIEW_APPOINTMENT,
    UPDATE_APPOINTMENT: import.meta.env.VITE_UPDATE_APPOINTMENT,
    DELETE_APPOINTMENT: import.meta.env.VITE_DELETE_APPOINTMENT,
    DELETE_STAFF: import.meta.env.VITE_DELETE_STAFF,
    GET_STAFF: import.meta.env.VITE_GET_STAFF, //Get STAFF
    CREATE_APPOINTMENT: undefined,
    GET_PATIENT_APPOINTMENTS: undefined,
    GET_DOCTOR_LIST: import.meta.env.VITE_GET_DOCTOR_LIST,
    UPDATE_USER: import.meta.env.VITE_UPDATE_PROFILE,
    VITE_CHANGE_PASSWORD: import.meta.env.VITE_CHANGE_PASSWORD,
    DOWNLOAD_STAFFLIST: import.meta.env.VITE_DOWNLOAD_STAFFLIST,
    UPDATE_PROFILE_IMAGE : import.meta.env.VITE_UPDATE_PROFILE_IMAGE,
    GET_NOTIFICATIONS : import.meta.env.VITE_GET_NOTIFICATIONS,
    DELETE_NOTIFICATION : import.meta.env.VITE_DELETE_NOTIFICATION,
    MARK_READ : import.meta.env.VITE_MARK_READ_NOTIFICATION,
    GET_DASHBOARD_TIME : import.meta.env.VITE_GET_DASHBOARD_TIME,
    CHANGE_PASSWORD: ""
}