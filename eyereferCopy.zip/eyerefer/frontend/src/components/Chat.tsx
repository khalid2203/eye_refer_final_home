/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import api from '../api/axiosInstance';
import { jwtDecode } from 'jwt-decode';
import '../css/Chat.css';
import { Local } from '../environment/env';
import { io, Socket } from 'socket.io-client';
import moment from 'moment';

const socket: Socket = io(`${Local.BASE_URL}`);

const fetchChatRooms = async (token: string) => {
    const response = await api.get(`${Local.BASE_URL}chat/chatRooms`, {
        headers: {
            Authorization: `Bearer ${token}`,
        },
    });
    return response.data;
};

const fetchChatMessages = async (chatRoomId: string, token: string) => {
    try {
        const response = await api.get(`${Local.BASE_URL}chat/chatMessages/${chatRoomId}`, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });
        return response.data;
    } catch (err) {
        console.error(err);
        throw err;
    }
};

const sendChatMessage = async (messageData: any, token: string) => {
    const response = await api.post(`${Local.BASE_URL}chat/sendMessage`, messageData, {
        headers: {
            Authorization: `Bearer ${token}`,
        },
    });
    return response.data;
};

const Chat: React.FC = () => {
    const navigate = useNavigate();
    const token: any = localStorage.getItem('token');
    const initialRoom: any = localStorage.getItem('roomId');
    const doctor_name: any = localStorage.getItem('doctor_name');
    const patientFirstName: any = localStorage.getItem('patientFirstName');
    const patientLastName: any = localStorage.getItem('patientLastName');
    const decoded: any = jwtDecode(token);
    const userId = decoded.uuid;
    const queryClient = useQueryClient();

    const [selectedRoom, setSelectedRoom] = useState<string | null>(initialRoom || null);
    const [selectedPatient, setSelectedPatient] = useState<any | null>(() => {
        if (doctor_name && patientFirstName && patientLastName) {
            return {
                doctor_name,
                patientFirstName,
                patientLastName,
            };
        }
        return null;
    });

    const [message, setMessage] = useState<string>('');
    const [chatMessages, setChatMessages] = useState<any[]>([]);
    const [isJoined, setIsJoined] = useState(false);
    const [searchTerm, setSearchTerm] = useState<string>('');

    const { data: chatRooms, isLoading: roomsLoading, error: roomsError } = useQuery({
        queryKey: ['chatRooms'],
        queryFn: () => fetchChatRooms(token!),
    });

    console.log("chatroomssssssssss", chatRooms?.length);

    const { mutate: sendMessage } = useMutation({
        mutationFn: (messageData: any) => sendChatMessage(messageData, token!),
        onSuccess: () => {
            setMessage('');
        },
        onError: (error) => {
            console.error('Error sending message:', error);
        },
    });

    useEffect(() => {
        if (!token) {
            navigate('/login');
        }

        queryClient.invalidateQueries({ queryKey: ['chatRooms'] });

        socket.on('receive_message', (messageData) => {
            setChatMessages((prevMessages) => [...prevMessages, messageData]);
        });

        return () => {
            socket.off('receive_message');
        };
    }, [token, navigate, queryClient]);

    useEffect(() => {
        if (selectedRoom) {
            if (isJoined) {
                socket.emit('leave_room', selectedRoom);
            }

            socket.emit('join_room', selectedRoom);
            setIsJoined(true);

            fetchChatMessages(selectedRoom, token!).then((messages) => {
                setChatMessages(messages);
            });
        }

        return () => {
            if (selectedRoom) {
                socket.emit('leave_room', selectedRoom);
                setIsJoined(false);
            }
        };
    }, [isJoined, selectedRoom, token]);

    useEffect(() => {
        return () => {
            localStorage.removeItem('roomId');
            localStorage.removeItem('doctor_name');
            localStorage.removeItem('patientFirstName');
            localStorage.removeItem('patientLastName');
        };
    }, []);

    const handleSelectRoom = (roomId: string, doctor_name: string, patientFirstName: string, patientLastName: string, profile_photo: string) => {
        setSelectedRoom(roomId);
        setSelectedPatient({ doctor_name, patientFirstName, patientLastName, profile_photo });
    };

    const handleSendMessage = () => {
        if (!message.trim()) return;

        const messageData = {
            chatRoomId: selectedRoom,
            senderId: userId,
            message,
        };

        socket.emit('send_message', messageData);
        sendMessage(messageData);
    };

    // Filter rooms based on search term
    const filteredChatRooms = chatRooms?.filter((room: any) => {
        const fullName = `${room.patientFirstName} ${room.patientLastName}`.toLowerCase();
        const doctorName = room.doctor_name.toLowerCase();
        return (
            fullName.includes(searchTerm.toLowerCase()) ||
            doctorName.includes(searchTerm.toLowerCase())
        );
    });

    const groupMessagesByDate = (messages: any[]) => {
        const groupedMessages: any[] = [];
        let currentDate = '';

        messages.forEach((msg) => {
            const messageDate = moment(msg.createdAt);

            const formattedDate = messageDate.isSame(moment(), 'day')
                ? 'Today'
                : messageDate.isSame(moment().subtract(1, 'day'), 'day')
                    ? 'Yesterday'
                    : messageDate.format('MMMM D, YYYY');

            if (formattedDate !== currentDate) {
                currentDate = formattedDate;
                groupedMessages.push({
                    date: formattedDate,
                    messages: [msg],
                });
            } else {
                groupedMessages[groupedMessages.length - 1].messages.push(msg);
            }
        });

        return groupedMessages;
    };


    return (
        <div className="chat-container row">
            {/* Left Panel - Chat Rooms List */}
            <div className="chat-header col">
                <h5>Messages</h5>
                <input
                    type="text"
                    className="form-control my-3"
                    placeholder="Search Patient..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
                <ul className="list-group">
                    {chatRooms?.length === 0 ? (
                        <div className="">
                            <div className="no-rooms-message d-flex justify-content-center text-primary">You haven't chat with anyone yet!</div>
                        </div>
                    ) : (
                        filteredChatRooms?.map((room: any) => (
                            <li
                                key={room.roomId}
                                className="list-group-item d-flex room-list"
                                onClick={() => handleSelectRoom(room.roomId, room.doctor_name, room.patientFirstName, room.patientLastName, room.profile_photo)}
                            >
                                <img className="p-img" src={room.profile_photo ? Local.BASE_URL + room.profile_photo : 'profile1.png'} alt="profile" />
                                <div>
                                    <div className="fw-bold">{room.patientFirstName} {room.patientLastName}</div>
                                    <small> Doctor: {room.doctor_name}</small>
                                </div>
                            </li>
                        ))
                    )}
                </ul>
            </div>

            {/* Right Panel - Chat Window */}
            <div className="chat-messages col">
                {selectedRoom ? (
                    <>
                        <div className="chat-header">
                            <div className='d-flex'>
                                <img className="p-img" src={selectedPatient.profile_photo ? Local.BASE_URL + selectedPatient.profile_photo : 'profile1.png'} alt="profile" />
                                <div>
                                    <div className='font-weight-bold'>{selectedPatient.doctor_name}</div>
                                    <small>{selectedPatient.patientFirstName} {selectedPatient.patientLastName}</small>
                                </div>
                            </div>
                            <div className='h-line'></div>
                        </div>
                        <div className="messages-container">
                            {groupMessagesByDate(chatMessages).map((group, index) => (
                                <div key={index}>
                                    <div className="message-date sticky-date">
                                        <div className="date-divider">
                                            <span className="date-text">
                                                {group.date === 'Today' || group.date === 'Yesterday'
                                                    ? group.date
                                                    : moment(group.date).format('MMMM D, YYYY')}
                                            </span>
                                        </div>
                                    </div>
                                    {group.messages.map((msg: any, messageIndex: number) => (
                                        <div key={messageIndex} className={`message ${msg.senderId === userId ? 'sent' : 'received'}`}>
                                            <div className={`${msg.senderId === userId ? 'sent-message' : 'received-message'}`}>{msg.message}</div>
                                            <div className={`${msg.senderId === userId ? 'sender-message-time' : 'receiver-message-time'}`}>
                                                {/* <small>{msg.senderId === userId ? `you : ` : ""}</small> */}
                                                <small>{moment(msg.createdAt).format('LT')}</small>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ))}
                        </div>

                        <div className="chat-input d-flex">
                            <input
                                className="form-control me"
                                placeholder="Type a message..."
                                value={message}
                                onChange={(e) => setMessage(e.target.value)}
                                onKeyDown={(event) => {
                                    if (event.key === 'Enter') {
                                        event.preventDefault();
                                        handleSendMessage();
                                    }
                                }}
                            />
                            <button onClick={handleSendMessage} className="btn btn-primary my-2">Send</button>
                        </div>
                    </>
                ) : (
                    <div className='d-flex justify-content-center text-primary'>No Patient selected, please select any patient!</div>
                )}
            </div>
        </div>
    );
};

export default Chat;
