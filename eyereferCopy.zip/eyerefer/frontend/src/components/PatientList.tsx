/* eslint-disable @typescript-eslint/no-explicit-any */
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Local } from '../environment/env';
import api from '../api/axiosInstance';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import '../css/PatientList.css';
import Pagination from './Pagination';

const PatientList: React.FC = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  const doctype = localStorage.getItem('doctype');

  const [page, setPage] = useState(1);
  const [limit] = useState(4);
  const [search, setSearch] = useState('');
  const [input, setInput] = useState('');
  const [sortOrder, setSortOrder] = useState('DESC');
  const queryClient = useQueryClient()

  useEffect(() => {
    if (!token) {
      navigate('/login');
    }
  }, [token, navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearch(input);
    setPage(1);
  };


  const deletePatientMutation = useMutation({
    mutationFn: async (patientId: string) => {
      try {
        const response = await api.delete(`${Local.DELETE_PATIENT}/${patientId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        return response.data;
      } catch (err: any) {
        throw new Error(`${err.message || 'Error deleting patient'}`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['patient'] });
      toast.success('Staff deleted successfully');
    },
    onError: (err) => {
      toast.error(`Error: ${err.message}`);
    },
  });

  const handleDeletePatient = (patientId: string) => {
    if (window.confirm('Are you sure you want to delete this patient?')) {
      deletePatientMutation.mutate(patientId);
    }
  };



  const fetchPatient = async () => {
    try {
      const response = await api.get(`${Local.GET_PATIENT_LIST}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        params: {
          page,
          limit,
          search,
          order: sortOrder
        },
      });
      return response.data;
    } catch (err) {
      toast.error(`${err}`);
    }
  };

  // Mutation to update patient status
  const { data: Patients, error, isLoading, isError } = useQuery({
    queryKey: ['patient', page, search, sortOrder],
    queryFn: fetchPatient,
  });

  if (isLoading) {
    return (
      <div className="loading-container">
        <div>Loading...</div>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="text-danger">Error: {error.message}</div>
    );
  }

  const totalPages = Patients?.pagination?.totalPages || 1;
  const currentPage = Patients?.pagination?.currentPage || 1;

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setPage(newPage);
    }
  };

  const handleSortClick = () => {
    setSortOrder(sortOrder === 'ASC' ? 'DESC' : 'ASC');
    // fetchDoctor()
  };


  // Handle Accept button click
  // const handleAccept = (patientId: string) => {
  //   mutation.mutate({ patientId, status: 1 });
  // };

  // Handle Reject button click
  // const handleReject = (patientId: string) => {
  //   mutation.mutate({ patientId, status: 2 });
  // };



  return (
    <div className="patient-list-container table-responsive">
      <div className="d-flex justify-content-between align-items-center">
        <h5 className="patient-list-title">Referred Patients</h5>
        {doctype == "1" ? <button className="appointment-btn" onClick={() => navigate("/add-appointment")}>+Add Appointment</button>
          : <button className="appointment-btn" onClick={() => navigate("/add-patient")}>+Add Referral Patient</button>}
      </div>
      {/* Search Form */}
      <form onSubmit={handleSearchSubmit} className="d-flex mb-4 search-b" role="search">
        <input
          className="form-control input-field"
          type="search"
          placeholder="Search..."
          aria-label="Search"
          value={input}
          onChange={handleInputChange}
        />
        <button className="btn btn-primary btn-search" type="submit">
          Search
        </button>
      </form>

      {/* Patient List Table */}
      <div className="table-responsive">
        <table className="table">
          <thead className="table-light">
            <tr>
              <th scope="col" className='p-name' onClick={handleSortClick}>Patient Name
                <i className={`fa-solid ${sortOrder === 'ASC' ? 'fa-angle-up' : 'fa-angle-down'} mx-2`}></i>
              </th>
              <th scope="col">Disease</th>
              <th scope="col">Refer by</th>
              <th scope="col">Refer to</th>
              <th scope="col">Refer back</th>

              <th scope="col">Status</th>
              <th scope="col" style={{ width: 100 }}>Action</th>
            </tr>
          </thead>
          <tbody>
            {Patients?.patientList?.length > 0 ? (
              Patients?.patientList.map((patient: any, index: number) => (
                <tr key={index}>
                  <td>
                    {patient.firstname} {patient.lastname}
                  </td>
                  <td>{patient.disease}</td>
                  <td>
                    {patient.referedby.firstname} {patient.referedby.lastname}
                  </td>
                  <td>
                    {patient.referedto.firstname} {patient.referedto.lastname}
                  </td>
                  <td>{patient.referback ? 'Yes' : 'No'}</td>
                  <td>
                    {patient?.referalstatus == 1 && (
                      <span className="text-success-1">Completed</span>
                    )}
                    {patient?.referalstatus == 0 && (
                      <span className="text-rejected-1">Rejected</span>
                    )}
                    {patient?.referalstatus == 2 && (
                      <span className="text-pending-1">Pending</span>
                    )}
                    {patient?.referalstatus == 3 && (
                      <span className="text-scheduled-1">Scheduled</span>
                    )}


                  </td>
                  <td>
                    <Link to={`/patient-details/${patient.uuid}`}>
                      <i className="fa-solid fa-eye" style={{ paddingRight: 5 }} title='Details'></i>
                    </Link>
                    {doctype == '2' && <Link to={`/update-patient/${patient.uuid}`}>
                      <i className="fa-solid fa-pen-to-square" style={{ paddingRight: 5 }} title='Update'></i>
                    </Link>}
                    {doctype == '2' && <span className="fa-solid fa-trash text-danger"
                      onClick={() => handleDeletePatient(patient.uuid)} title='Delete'>
                    </span>}

                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7}>No Patient found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      <Pagination
        totalPages={totalPages}
        currentPage={currentPage}
        handlePageChange={handlePageChange}
      />
    </div>
  );
};

export default PatientList;
