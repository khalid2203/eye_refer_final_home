/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Modal, Form, Button } from 'react-bootstrap';
import AddAddress from './AddAddress';
import { Local } from '../environment/env';
import '../css/Profile.css';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-toastify';
import { useUser } from './context/UserContext';

interface Address {
  uuid: string;
  id: string;
  street: string;
  city: string;
  state: string;
  pincode: string;
  phone: string;
}

interface User {
  profile_photo: string;
  gender: string;
  uuid: string;
  firstname: string;
  lastname: string;
  email: string;
  phone: string;
  doctype: number;
  Addresses?: Array<Address>;
}

interface ProfileData {
  user: User;
  message: string;
  patientCount?: number;
  referredPatients?: Array<any>;
  referredDoctors?: Array<any>;
  additionalData?: string;
}

const Profile: React.FC = () => {
  const [profile, setProfile] = useState<any | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAddAddressModal, setShowAddAddressModal] = useState(false);
  const [formData, setFormData] = useState<any | null>(null);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const token = localStorage.getItem('token');
  const { userData } = useUser(); // Ensure this context provides the user data.
  const queryClient = useQueryClient()

  // Fetch user data from context and set profile state
  useEffect(() => {
    if (userData) {
      setProfile({ user: userData.data, message: "Success" });
      setFormData(userData?.data?.user);
      console.log("formdataaaaaaaaaaa-----", userData.data);

    } else {
      console.error('User data is not available');
    }
  }, [userData]);

  const handleOpenEditModal = () => {
    if (profile) {
      setFormData({ ...userData?.data?.user });
    }
    setShowEditModal(true);
  };

  const handleCloseEditModal = () => setShowEditModal(false);

  const handleOpenAddAddressModal = () => setShowAddAddressModal(true);
  const handleCloseAddAddressModal = () => setShowAddAddressModal(false);

  const updateProfileImage = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('profile_photo', file);

      const response = await axios.put(`${Local.BASE_URL}${Local.UPDATE_PROFILE_IMAGE}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${token}`,
        },
      });
      queryClient.invalidateQueries({ queryKey: ['userData'] })


      return response.data;
    },
    onSuccess: () => {
      toast.success('Profile image updated successfully!');
    },
    onError: () => {
      toast.error('Error updating profile image!');
    },
  });

  const handleImageClick = () => {
    const fileInput = document.getElementById('file-input') as HTMLInputElement;
    fileInput?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      updateProfileImage.mutate(file);
    }
  };

  const handleProfileSubmit = () => {
    const token = localStorage.getItem('token');
    if (!formData) return;

    axios
      .post(
        `${Local.BASE_URL}${Local.UPDATE_USER}`,
        formData,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )
      .then(() => {
        setShowEditModal(false);
        queryClient.invalidateQueries({ queryKey: ['userData'] });
        toast.success('Profile updated successfully');
      })
      .catch((err) => {
        console.error(err);
        toast.error('Error updating profile');
      });
  };

  const handleInputChange = (e: any) => {
    if (formData) {
      const { name, value } = e.target;
      setFormData({ ...formData, [name]: value });
    }
  };

  const deleteAddressMutation = useMutation({
    mutationFn: async (addressId: string) => {
      try {
        const response = await axios.delete(`${Local.BASE_URL}${Local.DELETE_ADDRESS}/${addressId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });


        return response.data;
      } catch (err: any) {
        throw new Error(`${err.message || 'Error deleting address'}`);
      }
    },
    onSuccess: () => {
      toast.success('Address deleted successfully');
      queryClient.invalidateQueries({ queryKey: ['userData'] });
    },
    onError: (err) => {
      toast.error(`Error: ${err.message}`);
    },
  });

  const handleDeleteAddress = (addressId: string) => {
    if (window.confirm('Are you sure you want to delete this address?')) {
      deleteAddressMutation.mutate(addressId);
    }
  };

  if (!profile?.user) {
    return <div>Loading...</div>; // Show loading until the user data is available
  }

  const { user } = profile.user;
  console.log(user);



  return (
    <div className="profile-container">
      <h6 className="profile-title font-weight-bold">Profile</h6>

      <div className="profile-content">
        <div className="profile-info">
          <div className="img-name d-flex align-items-center">
            <img
              src={user.profile_photo ? Local.BASE_URL + user.profile_photo : 'profile1.png'}
              className="mr-3 profile-img"
              aria-expanded="false"
              onClick={handleImageClick}
              alt="Profile"
              style={{ cursor: 'pointer' }}
            />
            <h6 className="m-3">
              {user.firstname} {user.lastname}
            </h6>
            <input
              id="file-input"
              type="file"
              accept="image/*"
              style={{ display: 'none' }}
              onChange={handleFileChange}
            />
          </div>
          <button onClick={handleOpenEditModal} className="btn btn-primary mb-4">
            Edit Profile
          </button>
        </div>
        <div className="contact-info">
          <div className="name-gender">
            <div className="col-4 font-weight-bold">
              <span>Name: </span>{' '}
              <span className="text-secondary">{user.firstname} {user.lastname}</span>
            </div>
            <div className="font-weight-bold">
              <span>Gender:</span> <span className="text-secondary">{user.gender}</span>
            </div>
          </div>
          <div className="d-flex phone-email">
            <div className="col-4 font-weight-bold">
              <span>Phone:</span> <span className="text-secondary">{user.phone}</span>
            </div>
            <div className="font-weight-bold">
              <span>Email:</span> <span className="text-secondary">{user.email}</span>
            </div>
          </div>
          <a className="insurance-details-link" href="#">
            Insurance Details
          </a>
        </div>
        <div className="add-address-button">
          <button onClick={handleOpenAddAddressModal} className="btn btn-primary mb-4">
            Add Address
          </button>
        </div>
        <div className="address-list">
          <h6> Address information </h6>
          {user.Addresses?.map((add: any, index: any) => (
            <div className="text-secondary font-weight-bold" key={index}>
              <h5 className="text-black">
                {add.street}
                <i
                  onClick={() => handleDeleteAddress(add.uuid)}
                  className="fa-solid fa-trash m-3 delete-icon"
                ></i>
              </h5>
              <div>{add.phone}</div>
              <div>{add.city}</div>
              <div>{add.state}</div>
              <div>{add.pincode}</div>
              <div className="horizontal-line"></div>
            </div>
          ))}
        </div>
      </div>

      {/* Edit Profile Modal */}
      <Modal show={showEditModal} onHide={handleCloseEditModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Profile</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {formData && (
            <Form>
              <Form.Group controlId="firstname">
                <Form.Label className="required">First Name</Form.Label>
                <Form.Control
                  type="text"
                  name="firstname"
                  value={formData.firstname}
                  onChange={handleInputChange}
                />
              </Form.Group>

              <Form.Group controlId="lastname">
                <Form.Label className="required">Last Name</Form.Label>
                <Form.Control
                  type="text"
                  name="lastname"
                  value={formData.lastname}
                  onChange={handleInputChange}
                />
              </Form.Group>

              <Form.Group controlId="email">
                <Form.Label className="required">Email</Form.Label>
                <Form.Control
                  type="email"
                  name="email"
                  value={formData.email}
                  disabled
                  onChange={handleInputChange}
                />
              </Form.Group>

              <Form.Group controlId="gender">
                <Form.Label className="required">Gender</Form.Label>
                <Form.Select
                  aria-label="Select Gender"
                  name="gender"
                  value={formData.gender}
                  onChange={handleInputChange}
                >
                  <option>Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </Form.Select>
              </Form.Group>

              <Form.Group controlId="phone">
                <Form.Label className="required">Phone</Form.Label>
                <Form.Control
                  type="text"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                />
              </Form.Group>
            </Form>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseEditModal}>
            Close
          </Button>
          <Button variant="primary" onClick={handleProfileSubmit}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Add Address Modal */}
      <Modal show={showAddAddressModal} onHide={handleCloseAddAddressModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Add New Address</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <AddAddress close={handleCloseAddAddressModal} />
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default Profile;
