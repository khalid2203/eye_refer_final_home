import { useQuery } from '@tanstack/react-query';
import { Local } from '../environment/env';
import api from '../api/axiosInstance';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import '../css/DoctorList.css';
import Pagination from './Pagination';

const DoctorList: React.FC = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  const [page, setPage] = useState(1);
  const [limit] = useState(4);
  const [search, setSearch] = useState('');
  const [input, setInput] = useState('');
  const [sortOrder, setSortOrder] = useState('DESC'); // Default sort order for createdAt

  useEffect(() => {
    if (!token) {
      navigate('/login');
    }
  }, [navigate, token]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearch(input);
    setPage(1);
  };

  const fetchDoctor = async () => {
    try {
      const response = await api.get(`${Local.GET_DOCTOR_LIST}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        params: {
          page,
          limit,
          search,
          order: sortOrder,
        },
      });
      return response.data;
    } catch (err: any) {
      toast.error(`Error fetching doctor data: ${err.message}`);
    }
  };

  const { data: doctors, error, isLoading, isError } = useQuery({
    queryKey: ['doctor', page, search, sortOrder],
    queryFn: fetchDoctor,
  });

  const totalPages = doctors?.pagination?.totalPages || 1;
  const currentPage = doctors?.pagination?.currentPage || 1;

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setPage(newPage);
    }
  };

  const handleSortClick = () => {
    setSortOrder(sortOrder === 'ASC' ? 'DESC' : 'ASC');
    // fetchDoctor()
  };

  if (isLoading) {
    return (
      <div className="loading-container">
        <div className="loading-text">Loading...</div>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="error-container">
        <div className="text-danger">Error: {error.message}</div>
      </div>
    );
  }

  return (
    <div className="doctor-list-container">
      <h5 className="doctor-list-title">Doctors List</h5>

      {/* Search Form */}
      <form onSubmit={handleSearchSubmit} className="d-flex mb-4 search-b" role="search">
        <input
          className="form-control input-field"
          type="search"
          placeholder="Search"
          aria-label="Search"
          value={input}
          onChange={handleInputChange}
        />
        <button className="btn btn-primary btn-search" type="submit">
          Search
        </button>
      </form>

      {/* Doctor List Table */}
      <div className="table-container table-responsive">
        <table className="table">
          <thead className="table-primary">
            <tr>
              <th scope="col" className='p-name' onClick={handleSortClick}>
                Doctor Name
                <i className={`fa-solid ${sortOrder === 'ASC' ? 'fa-angle-up' : 'fa-angle-down'} mx-2`}></i>
              </th>
              <th scope="col">Gender</th>
              <th scope="col">Phone</th>
              <th scope="col">Email</th>
            </tr>
          </thead>
          <tbody>
            {doctors?.doctorList?.length > 0 ? (
              doctors?.doctorList?.map((doctor: any) => (
                <tr key={doctor.uuid}>
                  <td>{doctor.firstname} {doctor.lastname}</td>
                  <td>{doctor.gender ? doctor.gender : "-"}</td>
                  <td>{doctor.phone ? doctor.phone : "-"}</td>
                  <td>{doctor.email}</td>
                </tr>
              ))) : (
              <tr><td colSpan={4}>No doctor found</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      <Pagination
        totalPages={totalPages}
        currentPage={currentPage}
        handlePageChange={handlePageChange}
      />
    </div>
  );
};

export default DoctorList;
