/* eslint-disable @typescript-eslint/no-explicit-any */
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Local } from '../environment/env';
import React, { useEffect } from 'react';
import { toast } from 'react-toastify';
import api from '../api/axiosInstance';
import * as Yup from 'yup';
import "../css/AddPatient.css";
import { jwtDecode } from 'jwt-decode';
import { io } from 'socket.io-client';

const socket = io(`${Local.BASE_URL}`);
const AddPatient: React.FC = () => {
  const navigate = useNavigate();
  const token: any = localStorage.getItem("token");
  const decoded: any = jwtDecode(token);
  const userId = decoded.uuid;


  const addPatient = async (data: any) => {
    try {
      const formData = new FormData();

      Object.keys(data).forEach(key => {
        if (key !== 'document') {
          formData.append(key, data[key]);
        }
      });

      if (data.document) {
        formData.append('document', data.document);
      }
      const response = await api.post(`${Local.ADD_PATIENT}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${token}`
        }
      });
      console.log(response);
      toast.success("Patient referred successfully");
      emitNotification(data.referedto);
      navigate('/dashboard');
    } catch (err: any) {
      console.log(err);
      toast.error(`${err.response?.data?.message || 'Error occurred'}`);
    }
  };

  const emitNotification = (doctorId: string) => {
    const senderId = userId;
    const notificationMessage = `You have a new patient referral.`;

    // Emit the notification through socket
    socket.emit('send_notification', {
      receiverId: doctorId,
      senderId: senderId,
      notificationMessage: notificationMessage
    });
    // toast.success("Notification emitted to doctor");
  };

  useEffect(() => {
    if (!token) navigate('/login');
    if (localStorage.getItem("doctype") === '1') navigate('/dashboard');
  }, [navigate, token]);

  const fetchDocs = async () => {
    try {
      const response = await api.get(`${Local.GET_DOC_LIST}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      return response.data;
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Error fetching doctor list');
    }
  };

  const { data: MDList, isLoading, isError, error } = useQuery({
    queryKey: ["MDList"],
    queryFn: fetchDocs,
  });

  const patientMutate = useMutation({
    mutationFn: addPatient
  });

  const validationSchema = Yup.object().shape({
    firstname: Yup.string()
      .required('First name is required')
      .min(2, 'First name must be at least 2 characters')
      .max(50, 'First name can\'t be more than 50 characters')
      .matches(/^[A-Za-z]+$/, 'First name must only contain letters'),
    lastname: Yup.string()
      .required('Last name is required')
      .min(2, 'Last name must be at least 2 characters')
      .max(50, 'Last name can\'t be more than 50 characters')
      .matches(/^[A-Za-z]+$/, 'Last name must only contain letters'),
    disease: Yup.string().required("Disease is required"),
    timing: Yup.string().required("Timing is required"),
    dob: Yup.string()
      .required('Date is required')
      .test('is-future', 'DOB must be in the past', (value) => {
        if (!value) return false;
        const currentDate = new Date();
        const inputDate = new Date(value);
        return inputDate < currentDate;
      }),
    email: Yup.string().required("Email is required"),
    referedto: Yup.string().required("Select Doctor"),
    address: Yup.string().required("Address is required"),
    laterality: Yup.string().required("Laterality is required"),
    gender: Yup.string().required("Gender is required"),
    referback: Yup.string().required("Please select an option"),
    phone: Yup.string()
      .required('Phone number is required')
      .matches(/^[0-9]{10}$/, 'Phone number must be exactly 10 digits'),
  });

  const referPatientHandler = (values: any) => {
    patientMutate.mutate(values);
  };

  if (isLoading) {
    return (
      <div className="loading-container">
        <div>Loading...</div>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="error-container">
        <div>Error: {error?.message || 'Error loading data'}</div>
      </div>
    );
  }

  return (
    <div className="add-patient-container">
      <h5 className="form-title1">Add Referral Patient</h5>
      <Formik
        initialValues={{
          dob: '',
          email: '',
          phone: '',
          firstname: '',
          lastname: '',
          gender: '',
          disease: '',
          referedto: '',
          address: '',
          referback: '',
          timing: '',
          laterality: '',
          insurance: '',
          insurancePlan: '',
          consultNote: '',
          document: null
        }}
        validationSchema={validationSchema}
        onSubmit={referPatientHandler}
      >
        {({ values, setFieldValue }) => (
          <div className="form-container">
            <Form>
              <div className='font-weight-bold mb-4 mt-3'>Basic Information</div>
              <div className="row">
                <div className="form-group col">
                  <label className="required" id='dob'>DOB</label>
                  <Field type="date" name="dob" placeholder="Enter DOB" className="form-control" onClick={(e: any) => e.target.showPicker()} />
                  <ErrorMessage name="dob" component="div" className="text-danger" />
                </div>
                <div className="form-group col">
                  <label className="required">Email</label>
                  <Field type="text" name="email" placeholder="Enter email" className="form-control" />
                  <ErrorMessage name="email" component="div" className="text-danger" />
                </div>
                <div className="form-group col">
                  <label className="required">Phone Number</label>
                  <Field type="number" name="phone" maxlength={10} placeholder="Enter phone" className="form-control" />
                  <ErrorMessage name="phone" component="div" className="text-danger" />
                </div>
              </div>
              <div className="row">
                <div className="form-group col">
                  <label className="required">First Name</label>
                  <Field type="text" name="firstname" placeholder="Enter First Name" className="form-control" />
                  <ErrorMessage name="firstname" component="div" className="text-danger" />
                </div>

                <div className="form-group col">
                  <label className="required">Last Name </label>
                  <Field type="text" name="lastname" placeholder="Enter Last Name" className="form-control" />
                  <ErrorMessage name="lastname" component="div" className="text-danger" />
                </div>

                <div className="form-group col">
                  <label className="required">Gender</label>
                  <Field as="select" name="gender" className="form-control">
                    <option key="" value="">Select Gender</option>
                    <option key="male" value="male">Male</option>
                    <option key="female" value="female">Female</option>
                    <option key="other" value="other">Other</option>
                  </Field>
                  <ErrorMessage name="gender" component="div" className="text-danger" />
                </div>
              </div>

              <div className='font-weight-bold mb-4 mt-3'>Reason of Consult</div>
              <div className="row">
                <div className="form-group col">
                  <label className="required">Disease</label>
                  <Field as="select" name="disease" className="form-select">
                    <option value="" disabled>Choose Disease</option>
                    {['Color Blindness', 'Dry Eye', 'Floaters', 'Amblyopia (Lazy Eye)', 'Astigmatism'].map(disease => (
                      <option key={disease} value={disease}>{disease}</option>
                    ))}
                  </Field>
                  <ErrorMessage name="disease" component="div" className="text-danger" />
                </div>
                <div className="form-group col">
                  <label className="required">Laterality</label>
                  <Field as="select" name="laterality" className="form-select">
                    <option value="" disabled>Choose Laterality</option>
                    <option value="Left">Left</option>
                    <option value="Right">Right</option>
                    <option value="Both">Both</option>
                  </Field>
                  <ErrorMessage name="laterality" component="div" className="text-danger" />
                </div>

                <div className="form-group col">
                  <label className="form-label required">Patient to return to your care afterwards</label>
                  <div>
                    <label className="me-3">
                      <Field name="referback" type="radio" value="1" /> Yes
                    </label>
                    <label>
                      <Field name="referback" type="radio" value="0" /> No
                    </label>
                    <ErrorMessage name="referback" component="div" className="text-danger" />
                  </div>
                </div>
              </div>

              <div className="row">
                <div className='form-group col-4'>
                  <label className='required'>Timing</label>
                  <Field as="select" name="timing" className="form-control">
                    <option value="">Select Timing</option>
                    <option value="Routine (within 1 month)">Routine (Within 1 Month)</option>
                    <option value="Urgent (within 1 week)">Urgent (Within 1 Week)</option>
                    <option value="Emergent (within 24 hours or less)">Emergent (Within 24 hours or less)</option>
                  </Field>
                  <ErrorMessage name="timing" component="div" className="text-danger" />
                </div>
              </div>

              <div className='font-weight-bold mb-4 mt-3'>Refer to</div>
              <div className="row">
                <div className="form-group col-4">
                  <label className="required">MD Name</label>
                  <Field as="select" name="referedto" className="form-select" onChange={(e: { target: { value: any; }; }) => {
                    const selectedDoctorId = e.target.value;
                    setFieldValue("referedto", selectedDoctorId);
                    // Reset address when doctor changes
                    setFieldValue("address", "");
                  }}>
                    <option value="" disabled>Choose Doctor</option>
                    {MDList?.docList
                      .filter((md: any) => md.Addresses && md.Addresses.length > 0)
                      .map((md: any) => (
                        <option key={md.uuid} value={md.uuid}>{md.firstname} {md.lastname}</option>
                      ))
                    }
                  </Field>
                  <ErrorMessage name="referedto" component="div" className="text-danger" />
                </div>

                <div className="form-group col-4">
                  <label className="required">Add Location</label>
                  <Field as="select" name="address" className="form-select">
                    <option value="" disabled>Choose Address</option>
                    {values.referedto && MDList.docList.find((md: any) => md.uuid === values.referedto)?.Addresses.map((address: any) => (
                      <option key={address.uuid} value={address.uuid}>
                        {address.street} {address.district} {address.city} {address.state}
                      </option>
                    ))}
                  </Field>
                  <ErrorMessage name="address" component="div" className="text-danger" />
                </div>
              </div>

              <div className='font-weight-bold mb-4 mt-3'>Insurance Details</div>
              <div className="row">
                <div className="form-group col-4">
                  <label className="">Insurance Name</label>
                  <Field as="select" name="insurance" className="form-select">
                    <option value="" disabled>Choose Insurance</option>
                    <option value="smartData">smartData Inc.</option>
                    <option value="Policy Bazaar">Policy Bazaar</option>
                  </Field>
                </div>
                <div className="form-group col-4">
                  <label className="">Insurance Plan</label>
                  <Field as="select" name="insurancePlan" className="form-select">
                    <option value="" disabled>Choose Plan</option>
                    <option value="Basic">Basic</option>
                    <option value="Premium">Premium</option>
                  </Field>
                </div>
              </div>

              <div className='font-weight-bold mb-2 mt-3'>Medical Documents</div>
              <div className="row">
                <div className="form-group col-3">
                  <label className="">Upload Document</label>
                  <input
                    type="file"
                    name="document"
                    className="form-control"
                    onChange={(event: any) => {
                      const file = event.target.files ? event.target.files[0] : null;
                      if (file) {
                        setFieldValue("document", file);
                      }
                    }}
                  />
                  <ErrorMessage name="document" component="div" className="text-danger" />
                </div>
              </div>

              <div className="row">
                <div className="form-group">
                  <label className="">Notes</label>
                  <Field as="textarea" name="consultNote" className="form-control" />
                </div>
              </div>

              <div className="form-group text-center">
                <button type="submit" className="btn btn-outline-primary">Add Referral</button>
              </div>
            </Form>
          </div>
        )}
      </Formik>
    </div>
  );
};

export default AddPatient;
