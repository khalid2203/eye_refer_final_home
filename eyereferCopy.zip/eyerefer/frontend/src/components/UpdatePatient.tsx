import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import api from '../api/axiosInstance';
import '../css/UpdatePatient.css';
import { Local } from '../environment/env';

const UpdatePatient: React.FC = () => {
    const { patientId } = useParams<{ patientId: string }>();
    const navigate = useNavigate();
    const token = localStorage.getItem('token');

    // State for the form fields and loading status
    const [initialValues, setInitialValues] = useState({
        firstname: '',
        lastname: '',
        gender: '',
        dob: '',
        email: '',
        phone: '',
        laterality: '',
        insurance: '',
        insurancePlan: '',
        disease: '',
        address: '',
        timing: '',
        referedto: '',
        referback: '',
        consultNote: ''
    });

    const [isLoading, setIsLoading] = useState(true);

    // Validation schema using Yup
    const validationSchema = Yup.object({
        firstname: Yup.string()
            .required('First name is required')
            .min(2, 'First name must be at least 2 characters')
            .max(50, 'First name can\'t be more than 50 characters')
            .matches(/^[A-Za-z]+$/, 'First name must only contain letters'),
        lastname: Yup.string()
            .required('Last name is required')
            .min(2, 'Last name must be at least 2 characters')
            .max(50, 'Last name can\'t be more than 50 characters')
            .matches(/^[A-Za-z]+$/, 'Last name must only contain letters'),
        gender: Yup.string().required('Gender is required'),
        dob: Yup.date().required('Date of birth is required'),
        email: Yup.string().email('Invalid email format').required('Email is required'),
        phone: Yup.string()
            .required('Phone number is required')
            .matches(/^[0-9]{10}$/, 'Phone number must be exactly 10 digits')
    });

    // Fetch existing patient details
    useEffect(() => {
        const fetchPatientDetails = async () => {
            try {
                const response = await api.get(`${Local.GET_PATIENT_DETAILS}/${patientId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                const { patientDetails } = response.data;

                // Set initial form values with the fetched patient data
                setInitialValues({
                    firstname: patientDetails.firstname || '',
                    lastname: patientDetails.lastname || '',
                    gender: patientDetails.gender || '',
                    dob: patientDetails.dob || '',
                    email: patientDetails.email || '',
                    phone: patientDetails.phone || '',
                    laterality: patientDetails.laterality || '',
                    insurance: patientDetails.insurance || '',
                    insurancePlan: patientDetails.insurancePlan || '',
                    disease: patientDetails.disease || '',
                    address: patientDetails.address.street || '',
                    timing: patientDetails.timing || '',
                    referedto: patientDetails.referedto?.firstname || '',
                    referback: patientDetails.referback || '',
                    consultNote: patientDetails.notes || ''
                });
            } catch (error) {
                toast.error('Failed to fetch patient details');
                console.error(error);
            } finally {
                setIsLoading(false);
            }
        };

        console.log(initialValues.address);


        if (token) {
            fetchPatientDetails();
        } else {
            navigate('/login');
        }
    }, [patientId, token, navigate, initialValues.address]);

    const handleSubmit = async (values: typeof initialValues) => {
        try {
            const response = await api.put(`${Local.UPDATE_PATIENT_DETAILS}/${patientId}`, values, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    Authorization: `Bearer ${token}`,
                },
            });
            toast.success(response.data.message || 'Patient updated successfully');
            navigate(-1);
        } catch (error) {
            toast.error('Failed to update patient');
            console.error(error);
        }
    };

    if (isLoading) {
        return (
            <div className="spinner-border text-primary" role="status">
                <span className="visually-hidden">Loading...</span>
            </div>
        );
    }

    return (
        <div className="update-patient-container">
            <h3 className="mb-4">Update Patient Details</h3>
            <Formik
                initialValues={initialValues}
                enableReinitialize={true}
                validationSchema={validationSchema}
                onSubmit={handleSubmit}
            >
                {({ setFieldValue }) => (
                    <Form className="form-container">
                        <div className='font-weight-bold mb-4 mt-3'>Basic Information</div>
                        <div className="row">
                            <div className="form-group mb-3 col">
                                <label htmlFor="dob" className='required'>Date of Birth</label>
                                <Field
                                    type="date"
                                    id="dob"
                                    name="dob"
                                    className="form-control"
                                />
                                <ErrorMessage
                                    name="dob"
                                    component="div"
                                    className="text-danger"
                                />
                            </div>

                            <div className="form-group mb-3 col">
                                <label htmlFor="email" className='required'>Email</label>
                                <Field
                                    type="email"
                                    id="email"
                                    name="email"
                                    className="form-control"
                                />
                                <ErrorMessage
                                    name="email"
                                    component="div"
                                    className="text-danger"
                                />
                            </div>

                            <div className="form-group mb-3 col">
                                <label htmlFor="phone" className='required'>Phone</label>
                                <Field
                                    type="text"
                                    id="phone"
                                    name="phone"
                                    className="form-control"
                                    maxlength={10}
                                />
                                <ErrorMessage
                                    name="phone"
                                    component="div"
                                    className="text-danger"
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="form-group mb-3 col">
                                <label htmlFor="firstname" className='required'>First Name</label>
                                <Field
                                    type="text"
                                    id="firstname"
                                    name="firstname"
                                    className="form-control"
                                />
                                <ErrorMessage
                                    name="firstname"
                                    component="div"
                                    className="text-danger"
                                />
                            </div>

                            <div className="form-group mb-3 col">
                                <label htmlFor="lastname" className='required'>Last Name</label>
                                <Field
                                    type="text"
                                    id="lastname"
                                    name="lastname"
                                    className="form-control"
                                />
                                <ErrorMessage
                                    name="lastname"
                                    component="div"
                                    className="text-danger"
                                />
                            </div>

                            <div className="form-group mb-3 col">
                                <label htmlFor="gender" className='required'>Gender</label>
                                <Field
                                    as="select"
                                    id="gender"
                                    name="gender"
                                    className="form-control"
                                >
                                    <option value="">Select Gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </Field>

                                <ErrorMessage
                                    name="gender"
                                    component="div"
                                    className="text-danger"
                                />
                            </div>
                        </div>
                        <div className='font-weight-bold mb-4 mt-3'>Reason of Consult</div>
                        <div className="row">
                            <div className="form-group col">
                                <label className="required">Disease</label>
                                <Field as="select" name="disease" className="form-select">
                                    <option value="" disabled>Choose Disease</option>
                                    {['Color Blindness', 'Dry Eye', 'Floaters', 'Amblyopia (Lazy Eye)', 'Astigmatism'].map(disease => (
                                        <option key={disease} value={disease}>{disease}</option>
                                    ))}
                                </Field>
                                <ErrorMessage name="disease" component="div" className="text-danger" />
                            </div>
                            <div className="form-group col">
                                <label className="required">Laterality</label>
                                <Field as="select" name="laterality" className="form-select">
                                    <option value="" disabled>Choose Laterality</option>
                                    <option value="Left">Left</option>
                                    <option value="Right">Right</option>
                                    <option value="Both">Both</option>
                                </Field>
                            </div>

                            <div className="form-group col">
                                <label className="form-label required">Patient to return to your care afterwards</label>
                                <div>
                                    <label className="me-3">
                                        <Field name="referback" type="radio" value="true" /> Yes
                                    </label>
                                    <label>
                                        <Field name="referback" type="radio" value="false" /> No
                                    </label>
                                    <ErrorMessage name="referback" component="div" className="text-danger" />
                                </div>
                            </div>
                        </div>

                        <div className="row">
                            <div className='form-group col-4'>
                                <label className='required'>Timing</label>
                                <Field as="select" name="timing" className="form-control">
                                    <option value="">Select Timing</option>
                                    <option value="Routine (within 1 month)">Routine (Within 1 Month)</option>
                                    <option value="Urgent (within 1 week)">Urgent (Within 1 Week)</option>
                                    <option value="Emergent (within 24 hours or less)">Emergent (within 24 hours or less)</option>

                                </Field>
                            </div>
                        </div>
                        <div className='font-weight-bold mb-4 mt-3'>Refer to</div>
                        {/* Additional fields */}
                        <div className="row">
                            <div className="form-group mb-3 col">
                                <label htmlFor="referedto" className='required'>Referred To</label>
                                <Field
                                    type="text"
                                    id="referedto"
                                    name="referedto"
                                    className="form-control"
                                    disabled
                                />
                            </div>

                            <div className="form-group mb-3 col">
                                <label htmlFor="address" className='required'>Address</label>
                                <Field
                                    type="text"
                                    id="address"
                                    name="address"
                                    className="form-control"
                                    disabled
                                />
                            </div>
                        </div>



                        {/* <div className="form-group mb-3">
                            <label htmlFor="referback">Referred Back</label>
                            <Field
                                type="text"
                                id="referback"
                                name="referback"
                                className="form-control"
                            />
                        </div> */}
                        <div className='font-weight-bold mb-4 mt-3'>Insurance Details</div>
                        <div className="row">
                            <div className="form-group col-4">
                                <label className="">Insurance Name</label>
                                <Field as="select" name="insurance" className="form-select">
                                    <option value="" disabled>Choose Insurance</option>
                                    <option value="smartData">smartData Inc.</option>
                                    <option value="Policy Bazaar">Policy Bazaar</option>
                                </Field>
                            </div>
                            <div className="form-group col-4">
                                <label className="">Insurance Plan</label>
                                <Field as="select" name="insurancePlan" className="form-select">
                                    <option value="" disabled>Choose Plan</option>
                                    <option value="Basic">Basic</option>
                                    <option value="Premium">Premium</option>
                                </Field>
                            </div>
                            <div className='font-weight-bold mb-2 mt-3'>Medical Documents</div>
                            {/* <div className='font-weight-bold mb-2 mt-3'>Consult Note</div> */}
                            <div className="row">
                                <div className="form-group col-3">
                                    <label className="">Upload Document</label>
                                    <input
                                        type="file"
                                        name="document"
                                        className="form-control"
                                        onChange={(event: any) => {
                                            const file = event.target.files ? event.target.files[0] : null;
                                            if (file) {
                                                setFieldValue("document", file);
                                            }
                                        }}
                                    />
                                    <ErrorMessage name="document" component="div" className="text-danger" />
                                </div>
                            </div>
                            <div className="row">
                                <div className="form-group">
                                    <label className="">Notes</label>
                                    <Field as="textarea" name="consultNote" className="form-control" />
                                </div>
                            </div>
                        </div>

                        <button
                            type="submit"
                            className="btn btn-primary"
                        >
                            Update Patient
                        </button>
                        <Link className="btn btn-secondary" to='/dashboard'>Back</Link>
                    </Form>
                )}
            </Formik>
        </div>
    );
};

export default UpdatePatient;
