/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Local } from '../environment/env';
import api from '../api/axiosInstance';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { v4 as uuidv4 } from 'uuid';
import moment from 'moment';
import '../css/Dashboard.css';
import { jwtDecode } from 'jwt-decode';
import { useUser } from './context/UserContext';
import Pagination from './Pagination';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const token: any = localStorage.getItem("token");
  const decoded: any = jwtDecode(token);
  const userId = decoded.uuid;
  const [page, setPage] = useState(1);
  const [limit] = useState(4);
  const [sortOrder, setSortOrder] = useState('DESC'); // Default sort order for createdAt
  const { userData, isLoading: userLoading } = useUser();

  useEffect(() => {
    // console.log("usecontext userdata..........", userData);
    if (!token) {

      navigate("/login");
    }


  }, [token, navigate, userId, userData]);




  // Mutation to create the chat room
  const createChatRoomMutation = useMutation({
    mutationFn: async ({ referedById, referedToId, patientId, roomId }: any) => {
      try {
        const response = await api.post(`${Local.BASE_URL}chat/createRoom`, {
          referedById,
          referedToId,
          patientId,
          roomId
        }, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        localStorage.setItem('roomId', response.data.roomId)
        navigate('/chat')
        // console.log("room details->>>>>>>>>>>>>>>>", response.data.roomId);

        return response.data;
      } catch (err) {
        console.error("Error creating chat room", err);
      }
    }
  });



  const fetchPatientList = async () => {
    try {
      const response = await api.get(`${Local.GET_PATIENT_LIST}`, {
        headers: {
          Authorization: `Bearer ${token}`
        },
        params: {
          page,
          limit,
          order: sortOrder
        },
      });
      return response.data;
    } catch (err) {
      toast.error("Failed to fetch patient data");
    }
  };

  const { data: patientData, isLoading: patientLoading } = useQuery({
    queryKey: ['patientData', page, sortOrder],
    queryFn: fetchPatientList
  });

  // console.log("Patient Data->>>", patientData);


  const fetchDashboardTime = async () => {
    try {
      const response = await api.get(`${Local.GET_DASHBOARD_TIME}`, {
        headers: {
          Authorization: `Bearer ${token}`
        },
      });
      return response.data;
    } catch (err) {
      toast.error("Failed to fetch patient data");
    }
  };

  const { data: updatedTime } = useQuery({
    queryKey: ['updateTime'],
    queryFn: fetchDashboardTime
  });

  console.log("Latest time", updatedTime);

  if (userLoading || patientLoading) {
    return (
      <div className="loading-container">
        <div>Loading...</div>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  const { patientList, pagination } = patientData || {};
  const { user } = userData?.data || {};

  const handleSortClick = () => {
    setSortOrder(sortOrder === 'ASC' ? 'DESC' : 'ASC');
    // fetchDoctor()
  };

  const dataToSent = userData?.data;
  // console.log("datatosentttttt", dataToSent);

  const handleNavigateToGraph = () => {
    navigate('/graph', { state: { dataToSent } });
  };

  const totalPages = pagination?.totalPages || 1;
  const currentPage = pagination?.currentPage || 1;

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setPage(newPage);
    }
  };

  const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);

  const handleCreateChatRoom = (referedById: string, referedToId: string, patientId: string) => {
    const roomId = uuidv4();
    createChatRoomMutation.mutate({
      referedById,
      referedToId,
      patientId,
      roomId
    });
  };

  const setRoomDetailsToLocal = (referedById: string, patientFirstname: string, patientLastname: string, referedtoFirstname: string, referedtoLastname: string, referedbyFirstname: string, referedbyLastname: string) => {
    localStorage.setItem("patientFirstName", patientFirstname)
    localStorage.setItem("patientLastName", patientLastname)
    if (referedById === userId) {
      localStorage.setItem("doctor_name", referedtoFirstname + ' ' + referedtoLastname)
    } else {
      localStorage.setItem("doctor_name", referedbyFirstname + ' ' + referedbyLastname)
    }
  }

  return (
    <div className="dashboard-container">
      {/* <Graph /> */}

      <div className='header-title d-flex justify-content-between'>
        <h5 className="dashboard-title">Dashboard</h5>
        <div className="dashboard-title btn btn-info" onClick={handleNavigateToGraph}><i className="fa-solid fa-chart-line"></i></div>
      </div>

      <div className="metrics-cards">
        <div className="card" onClick={() => navigate('/patient')}>
          <div className="card-body">
            <div className="card-title">Referrals Placed</div>
            <div className="text-img">
              <img className='text-danger total-img' src='total.svg' alt="referrals-icon" />
              <div className="card-text text-black">{userData?.data.referCount}</div>
            </div>
            <div className="div text-end">
              <small className="last-updated text-secondary font-weight-bold">Last updated: {updatedTime?.patientTableTime?.updatedAt ? moment(updatedTime?.patientTableTime?.updatedAt).format("MMM DD") : 'N/A'}</small>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-body">
            <div className="card-title">Refers Completed</div>
            <div className="text-img">
              <img className='text-danger total-img' src='completed.svg' alt="referrals-icon" />
              <div className="card-text text-black">{userData?.data?.referCompleted}</div>
            </div>
            <div className="div text-end">
              <small className="last-updated text-secondary font-weight-bold">Last updated: {updatedTime?.referCompleted?.updatedAt ? moment(updatedTime?.referCompleted?.updatedAt).format("MMM DD") : 'N/A'}</small>
            </div>
          </div>
        </div>

        <div className="card" onClick={() => navigate('/doctor')}>
          <div className="card-body">
            <div className="card-title">OD/MD</div>
            <div className="text-img">
              <img className='text-danger total-img' src='doctor.png' alt="referrals-icon" />
              <div className="card-text text-black">{userData?.data.docCount}</div>
            </div>
            <div className="text-end">
              <small className="last-updated text-secondary font-weight-bold">Last updated: {updatedTime?.userTableTime?.updatedAt ? moment(updatedTime?.userTableTime?.updatedAt).format("MMM DD") : 'N/A'}</small>
            </div>
          </div>
        </div>
      </div>

      <div className='refer d-flex align-items-center'>
        {user.doctype === 2 ? (
          <>
            <h5 className="refer-title">Referrals Placed</h5>
            <button className="appointment-btn" onClick={() => navigate("/add-patient")}>+Add Referral Patient</button>
          </>
        ) : (
          <>
            <h5 className="refer-title">Referrals Placed</h5>
            <button className="appointment-btn" onClick={() => navigate("/add-appointment")}>+Add Appointment</button>
          </>
        )}
      </div>

      <div className="patient-list-section">
        <div className="table-responsive">
          <table className="table">
            <thead className='table-light'>
              <tr>
                <th className='col p-name' onClick={handleSortClick}>Patient Name
                  <i className={`fa-solid ${sortOrder === 'ASC' ? 'fa-angle-up' : 'fa-angle-down'} mx-2`}></i>
                </th>
                <th className='col'>DOB</th>
                <th className='col'>Consult</th>
                <th className='col'>Date Sent</th>
                <th className='col'>Doctor OD/MD</th>
                <th className='col'>Return to referal</th>
                <th className='col'>Status</th>
                <th className='col'>Direct Message</th>
              </tr>
            </thead>
            <tbody>
              {patientList?.length > 0 ? (
                patientList?.map((patient: any, index: number) => (
                  <tr key={index}>
                    <td className='text-primary link-1 p-name' onClick={() => {
                      navigate(`/patient-details/${patient.uuid}`)
                    }}>{patient.firstname} {patient.lastname}</td>
                    <td>{moment(patient.dob).format('MMM-DD-YYYY')}</td>
                    <td>{patient.disease}</td>
                    <td>{moment(patient.createdAt).format('MMM-DD-YYYY')}</td>
                    <td>{patient.referedby.uuid == userId ? patient.referedto.firstname + ' ' + patient.referedto.lastname : patient.referedby.firstname + ' ' + patient.referedby.lastname}</td>
                    {/* <td>{patient.referedto.firstname} {patient.referedto.lastname}</td> */}
                    <td>{patient.referback ? 'Yes' : 'No'}</td>
                    <td>
                      <span
                        className={`${patient?.referalstatus == 1 ? 'text-success-1' : patient?.referalstatus == 3 ? 'text-scheduled-1' :
                          patient?.referalstatus == 0 ? 'text-rejected-1' :
                            'text-pending-1'}`}
                      >
                        {/* Display status text */}
                        {patient?.referalstatus == 1 && 'Completed'}
                        {patient?.referalstatus == 0 && 'Rejected'}
                        {patient?.referalstatus == 2 && 'Pending'}
                        {patient?.referalstatus == 3 && 'Scheduled'}
                      </span>

                    </td>
                    {/* <td onClick={() => handleCreateChatRoom(patient.referedby.uuid, patient.referedto.uuid, patient.uuid)}>
                      <Link className='text-primary' to='/chat'>Link</Link>
                    </td> */}
                    <td
                      onClick={() => {
                        handleCreateChatRoom(patient.referedby.uuid, patient.referedto.uuid, patient.uuid);
                        setRoomDetailsToLocal(
                          patient.referedby.uuid,
                          patient.firstname,
                          patient.lastname,
                          patient.referedto.firstname,
                          patient.referedto.lastname,
                          patient.referedby.firstname,
                          patient.referedby.lastname
                        );
                      }}
                    ><div className='text-primary link-1' title='chat'>Link</div></td>
                  </tr>
                ))) : (
                <tr><td colSpan={8}>No Patient Found</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      <Pagination
        totalPages={totalPages}
        currentPage={currentPage}
        handlePageChange={handlePageChange}
      />
    </div>
  );
};

export default Dashboard;
