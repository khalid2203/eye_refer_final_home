/* eslint-disable @typescript-eslint/no-explicit-any */
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { useQuery } from '@tanstack/react-query';
import { Local } from '../environment/env';
import api from '../api/axiosInstance';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import * as Yup from 'yup';
import '../css/Appoinment.css';
import { io } from 'socket.io-client';
import { jwtDecode } from 'jwt-decode';

const socket = io(`${Local.BASE_URL}`);

const AddAppointment: React.FC = () => {
    const navigate = useNavigate();
    const token: any = localStorage.getItem("token");
    const decoded: any = jwtDecode(token);
    const userId = decoded.uuid;
    const [loading, setLoading] = useState(false);
    const [sortOrder, setSortOrder] = useState('DESC');


    const fetchPatients = async () => {
        try {
            const response = await api.get(`${Local.GET_PATIENT_LIST}`, {
                headers: { Authorization: `Bearer ${token}` },
                params: {
                    order: sortOrder
                }
            });
            return response.data;
        } catch (err: any) {
            toast.error(err.response?.data?.message || 'Error fetching patient list');
        }
    };

    const { data: patientList, isLoading, isError, error } = useQuery({
        queryKey: ['patients'],
        queryFn: fetchPatients,
    });
    console.log("appointment details patient list", patientList);

    const addAppointment = async (values: any) => {
        const appointmentData = {
            appointmentDate: values.date,
            patientId: values.patientId,
            appointmentType: values.type,
        };

        setLoading(true);

        try {
            const response = await api.post(`${Local.ADD_APPOINTMENT}`, appointmentData, {
                headers: { Authorization: `Bearer ${token}` },
            });
            console.log("addd apppointmetn response......", response);
            emitNotification(response?.data.referedById, response?.data?.patientName)
            toast.success('Appointment added successfully!');
            navigate('/appointments');
        } catch (err: any) {
            toast.error(err.response?.data?.message || 'Error adding appointment');
        } finally {
            setLoading(false);
        }
    };


    const emitNotification = (referedbyId: string, patientName: string) => {
        const senderId = userId;
        const notificationMessage = `${patientName} appointment is fixed`;

        // Emit the notification through socket
        socket.emit('send_notification', {
            receiverId: referedbyId,
            senderId: senderId,
            notificationMessage: notificationMessage
        });
        // toast.success("Notification emitted to doctor");
    };

    const validationSchema = Yup.object().shape({
        patientId: Yup.string().required('Patient Name is required'),
        date: Yup.string()
            .required('Date is required')
            .test('is-future', 'Date must be in the future', (value) => {
                if (!value) return false;
                const currentDate = new Date();
                const inputDate = new Date(value);
                return inputDate > currentDate;
            }),
        type: Yup.string().required('Appointment type is required'),
    });


    useEffect(() => {
        if (!token) {
            navigate('/login');
        }
    }, [token, navigate]);

    if (isLoading) {
        return (
            <div className="loading-container">
                <div>Loading...</div>
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
            </div>
        );
    }

    const handleBackButton = () => {
        navigate(-1)
    }

    if (isError) {
        return (
            <div className="error-container">
                Error: {error?.message || 'Failed to load patient data'}
            </div>
        );
    }

    return (
        <div className="add-appointment-container">
            <h5 className="form-title2">Add New Appointment</h5>
            <Formik
                initialValues={{
                    patientId: '',
                    date: '',
                    type: '',
                }}
                validationSchema={validationSchema}
                onSubmit={addAppointment}
            >
                {() => (
                    <Form>
                        <div className="base-form">

                            <div className="row">
                                <div className="form-group col">
                                    <label className="required">Patient Name</label>
                                    <Field as="select" name="patientId" className="form-select">
                                        <option value="" disabled>Select Patient</option>
                                        {patientList.patientList?.filter((patient: any) => patient.referalstatus == 2).map((patient: any) => (
                                            <option key={patient.uuid} value={patient.uuid}>
                                                {patient.firstname} {patient.lastname}
                                            </option>
                                        ))}
                                    </Field>
                                    <ErrorMessage name="patientId" component="div" className="text-danger" />
                                </div>

                                <div className="form-group col">
                                    <label className="required">Date</label>
                                    <Field type="date" name="date" className="form-control"
                                        onClick={(e: any) => e.target.showPicker()}
                                    />
                                    <ErrorMessage name="date" component="div" className="text-danger" />
                                </div>

                                <div className="form-group col">
                                    <label className="required">Appointment Type</label>
                                    <Field as="select" name="type" className="form-select">
                                        <option value="" disabled>Select Appointment Type</option>
                                        <option value="Consultation">Consultation</option>
                                        <option value="Surgery">Surgery</option>
                                        {/* <option value="Emergency">Emergency</option> */}
                                    </Field>
                                    <ErrorMessage name="type" component="div" className="text-danger" />
                                </div>
                            </div>

                            <div className="form-group row">
                                <button type="submit" className="btn btn-primary col add-appoi-btn" disabled={loading}>
                                    {loading ? 'Adding Appointment...' : 'Add Appointment'}
                                </button>
                                <div className='col'>
                                    {/* <Link className="btn btn-secondary" to="/dashboard">Back</Link> */}
                                    <div className="btn btn-secondary" onClick={handleBackButton}>Back</div>
                                </div>
                            </div>
                        </div>
                    </Form>
                )}
            </Formik>
        </div>
    );
};

export default AddAppointment;
