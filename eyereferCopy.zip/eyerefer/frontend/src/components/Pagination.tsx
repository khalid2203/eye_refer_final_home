import React from 'react';

interface PaginationProps {
    totalPages: number;
    currentPage: number;
    handlePageChange: (page: number) => void;
}

const Pagination: React.FC<PaginationProps> = ({ totalPages, currentPage, handlePageChange }) => {
    const pageNumbers: (number | string)[] = [];

    const getPaginationPages = () => {
        if (totalPages <= 5) {
            for (let i = 1; i <= totalPages; i++) {
                pageNumbers.push(i);
            }
        } else {
            pageNumbers.push(1, 2);

            if (currentPage > 3) pageNumbers.push('...');

            const start = Math.max(currentPage - 1, 3);
            const end = Math.min(currentPage + 1, totalPages - 2);

            for (let i = start; i <= end; i++) {
                if (!pageNumbers.includes(i)) pageNumbers.push(i);
            }

            if (currentPage < totalPages - 2) pageNumbers.push('...');

            pageNumbers.push(totalPages - 1, totalPages);
        }
    };

    getPaginationPages();

    return (
        <nav aria-label="Page navigation example">
            <ul className="pagination justify-content-end p-name">
                {/* Previous page */}
                <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                    <a
                        className="page-link"
                        href="#"
                        onClick={(e) => {
                            e.preventDefault();
                            if (currentPage > 1) handlePageChange(currentPage - 1);
                        }}
                        aria-label="Previous"
                    >
                        &laquo;
                    </a>
                </li>

                {/* Page Numbers */}
                {pageNumbers.map((num, index) => (
                    num === '...' ? (
                        <li key={`ellipsis-${index}`} className="page-item disabled">
                            <span className="page-link">...</span>
                        </li>
                    ) : (
                        <li
                            key={`page-${num}`}
                            className={`page-item ${currentPage === num ? 'active' : ''}`}
                        >
                            <a
                                className="page-link"
                                href="#"
                                onClick={(e) => {
                                    e.preventDefault();
                                    handlePageChange(num as number);
                                }}
                            >
                                {num}
                            </a>
                        </li>
                    )
                ))}

                {/* Next page */}
                <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                    <a
                        className="page-link"
                        href="#"
                        onClick={(e) => {
                            e.preventDefault();
                            if (currentPage < totalPages) handlePageChange(currentPage + 1);
                        }}
                        aria-label="Next"
                    >
                        &raquo;
                    </a>
                </li>
            </ul>
        </nav>
    );
};

export default Pagination;
