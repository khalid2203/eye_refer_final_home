import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import { useQuery } from '@tanstack/react-query';
import api from '../api/axiosInstance';
import { Local } from '../environment/env';
import '../css/PatientDetails.css'
import moment from 'moment';

const PatientDetails: React.FC = () => {
    const { patientId } = useParams<{ patientId: string }>();
    const token = localStorage.getItem('token');
    const navigate = useNavigate();

    const getPatient = async () => {
        try {
            const response = await api.get(`${Local.GET_PATIENT_DETAILS}/${patientId}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            return response.data.patientDetails;
        } catch (err) {
            toast.error("Failed to fetch user data");
            console.log(err)
        }
    };

    const { data: patientData, isError, error, isLoading } = useQuery({
        queryKey: ['patientData?'],
        queryFn: getPatient
    });


    console.log("patttttttient-------", patientData);

    useEffect(() => {
        if (!token) {
            navigate('/login')
        }
    }, [navigate, token]);

    if (isLoading) {
        return (
            <div className="spinner-border text-primary" role="status">
                <span className="visually-hidden">Loading...</span>
            </div>
        );
    }

    if (isError) {
        return <div className="text-danger">Error: {error instanceof Error ? error.message : 'An error occurred'}</div>;
    }

    if (!patientData) {
        return <div>Patient not found.</div>;
    }

    return (
        <div className="patient-details-container">
            {/* <div className='details-btn'>
                <p  className='back fw-bold' onClick={() => navigate("/patient")}><IoIosArrowBack /> Back</p >
                <button className="appointment-btn" onClick={() => navigate("/add-patient")}>+Add Referral Patient</button>
            </div> */}
            <div className='patient-info'>
                <h6 className="fw-bold" style={{ marginTop: '1.5rem', marginBottom: "1.5rem" }}>Basic Information</h6>
                <div className="patient-details">
                    <form>
                        <div className='name-info row'>
                            <div className="form-group2 col" style={{ marginTop: 15 }}>
                                <label htmlFor="name"><span className='text-black'>First Name: </span>{patientData?.firstname} {patientData?.lastname}</label>
                            </div>

                            <div className="form-group2 col " style={{ marginTop: 15 }}>
                                <label htmlFor="gender"><span className='text-black'>Gender: </span>{patientData?.gender}</label>
                            </div>
                            <div className="form-group2 col" style={{ marginTop: 15 }}>
                                <label htmlFor="date"><span className='text-black'>Date Of Birth: </span>{moment(patientData?.dob).format('ll')}</label>
                            </div>

                        </div>
                        <div className="form-group4 name-info row py-3">
                            <div className="form-group2 col">
                                <label htmlFor="phone"><span className='text-black'>Phone: </span>{patientData?.phone}</label>
                            </div>
                            <div className="form-group2 col">
                                <label htmlFor="email"><span className='text-black'>Email: </span>{patientData?.email}</label>
                            </div>
                            <div className="form-group2 col">
                                {/* <label htmlFor="email">Email: {patientData?.email}</label> */}
                            </div>
                        </div>



                        <p className='fw-bold' style={{ marginTop: '1.5rem', marginBottom: "1.5rem", fontSize: 16, color: "black" }}>Reason of consult</p >

                        <div className='name-info row'>
                            <div className="form-group2 col p-3" >
                                <label htmlFor="text"><span className='text-black'>Reason: </span>{patientData?.disease}</label>
                            </div>

                            <div className="form-group2 col p-3">
                                <label htmlFor="text"><span className='text-black'>Laterality: </span>{patientData?.laterality}</label>
                            </div>
                            <div className="form-group2 col p-3">
                                <label htmlFor="text"><span className='text-black'>Timing: </span>{patientData?.timing}</label>
                            </div>
                        </div>


                        <p className='fw-bold' style={{ marginTop: '1.5rem', marginBottom: "1.5rem", fontSize: 16, color: "black" }}>Referral OD/MD</p >

                        <div className='name-info row'>
                            <div className="form-group2 col p-3">
                                <label htmlFor="name"><span className='text-black'>MD/OD Name: </span>{`${patientData?.referedto?.firstname} ${patientData?.referedto?.lastname}`}</label>
                            </div>

                            <div className="form-group2 col p-3">
                                <label htmlFor="gender"><span className='text-black'>Location: </span>{patientData?.address?.street}</label>
                            </div>
                            <div className="form-group2 col p-3">
                                {/* <label htmlFor="date">Speciality: {patientData?.speciality}</label> */}
                            </div>
                        </div>


                        <p className='fw-bold' style={{ marginTop: '1.5rem', marginBottom: "1.5rem", fontSize: 16, color: "black" }}>Appointment Details</p >

                        <div className='name-info row'>
                            <div className="form-group2 col-4 p-3">
                                <label htmlFor="name"><span className='text-black'>Appointment Date: </span>{moment(patientData?.appointment?.appointmentDate).format('ll')}</label>
                            </div>
                            <span className="form-group2 col-4 p-3">
                                <label htmlFor="text" style={{}}><span className='text-black'>Type: </span>{patientData?.appointment?.appointmentType}</label>
                            </span  >


                        </div>

                        <p className='fw-bold' style={{ marginTop: '1.5rem', marginBottom: "1.5rem", fontSize: 16, color: "black" }}>Insurance Details</p >

                        <div className='name-info row'>
                            <div className="form-group2 col p-3">
                                <label className='text-black' htmlFor="name"><span className='text-black'>Company Name: </span>{patientData?.insurance}</label>
                            </div>

                            <div className="form-group2 col p-3">
                                <label htmlFor="gender"><span className='text-black'>Plan: </span>{patientData?.insurancePlan}</label>
                            </div>

                            <div className="form-group2 col p-3">
                                {/* <label htmlFor="gender">Policy End Date: {moment(patientData?.policyExpireDate).format("DD-MM-YYYY")}</label> */}
                            </div>
                        </div>
                        <p className='fw-bold' style={{ marginTop: '1.5rem', marginBottom: "1.5rem", fontSize: 16, color: "black" }}>Patient Document</p >
                        <div className='name-info row'>
                            <div className="form-group2 col p-3">
                                {patientData?.document ? <Link className='btn btn-primary' to={`${Local.BASE_URL}${patientData?.document}`} ><i className="fa-solid fa-download"></i> Download</Link> : "No Document Available"}

                                {/* <a href={`${Local.BASE_URL}${patientData?.document}`}>Download Document</a> */}
                            </div>
                        </div>

                        <p className='fw-bold' style={{ marginTop: '1.5rem', marginBottom: "1.5rem", fontSize: 16, color: "black" }}>Notes</p >

                        <div className='name-info row'>
                            <div className="form-group2 col p-3">
                                <label htmlFor="name"><span className='text-black'></span>{patientData?.notes}</label>
                            </div>
                        </div>


                        {/* <div className="form-group2 col">
                        <label htmlFor="referedBy">MD/OD Name {`${patientData?.referedby?.firstname} ${patientData?.referedby?.lastname}`}</label> 
                    </div> */}

                    </form>
                    <button className="btn btn-primary my-2 mx-0" onClick={() => navigate(-1)}>
                        Back
                    </button>
                </div>
            </div>
        </div>
    );
};

export default PatientDetails;