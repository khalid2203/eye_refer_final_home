import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Local } from '../environment/env';
import api from '../api/axiosInstance';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import '../css/AppoinmentList.css';
import Pagination from './Pagination';

const AppointmentsList: React.FC = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  const queryClient = useQueryClient();
  // const doctype = localStorage.getItem('doctype')
  const [page, setPage] = useState(1);
  const [limit] = useState(4);
  const [search, setSearch] = useState('');
  const [input, setInput] = useState('');
  const [sortOrder, setSortOrder] = useState('DESC');

  useEffect(() => {
    if (!token) {
      navigate('/login');
    }
  }, [token, navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearch(input);
    setPage(1);
  };

  const mutation = useMutation({
    mutationFn: async ({ patientId, status }: { patientId: string; status: string }) => {
      try {
        const response = await api.put(
          '/update-patient-status',
          {
            patientId,
            referalstatus: status,
          },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        return response.data;
      } catch (error) {
        toast.error('Error updating status');
        console.error(error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
      toast.success('Patient status updated successfully');
    },
    onError: () => {
      toast.error('Failed to update status');
    },
  });

  const handleAccept = (patientId: string) => {
    mutation.mutate({ patientId, status: '1' });
  };

  const handleReject = (patientId: string) => {
    mutation.mutate({ patientId, status: '0' });
  };

  const fetchAppointments = async () => {
    try {
      const response = await api.get(`${Local.GET_APPOINTMENT}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        params: {
          page,
          limit,
          search,
          order: sortOrder,
        },
      });
      return response.data;
    } catch (err: any) {
      toast.error(`${err.message || 'Error fetching appointments data'}`);
    }
  };

  const { data: appointmentsData, error, isLoading, isError } = useQuery({
    queryKey: ['appointments', page, search, sortOrder],
    queryFn: fetchAppointments,
  });

  // console.log(appointmentsData);

  const totalPages = appointmentsData?.pagination?.totalPages || 1;
  const currentPage = appointmentsData?.pagination?.currentPage || 1;

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setPage(newPage);
    }
  };

  const handleSortClick = () => {
    setSortOrder(sortOrder === 'ASC' ? 'DESC' : 'ASC');
    // fetchDoctor()
  };


  const deleteAppointmentMutation = useMutation({
    mutationFn: async (appointmentId: string) => {
      try {
        const response = await api.delete(`${Local.DELETE_APPOINTMENT}/${appointmentId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        return response.data;
      } catch (err: any) {
        throw new Error(`${err.message || 'Error deleting appointment'}`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['appointments'] })
      toast.success('Appointment deleted successfully');
    },
    onError: (err) => {
      toast.error(`Error: ${err.message}`);
    },
  });

  const handleDeleteAppointment = (appointmentId: string) => {
    if (window.confirm('Are you sure you want to delete this appointment?')) {
      deleteAppointmentMutation.mutate(appointmentId);
    }
  };

  if (isLoading) {
    return (
      <div className="loading-container">
        <div>Loading...</div>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="text-danger">
        Error: {error.message || 'Failed to load appointments data'}
      </div>
    );
  }

  return (
    <div className="appointments-list-container">
      <div className="appointments-list-header">
        <h5 className="appointments-list-title">Appointments List</h5>
        <div className="add-appointment-button">
          <button
            onClick={() => navigate('/add-appointment')}
            className="add-appointment-btn"
          >
            Add Appointment
          </button>
        </div>
      </div>

      <form onSubmit={handleSearchSubmit} className="d-flex search-b" role="search">
        <input
          className="form-control input-field"
          type="search"
          placeholder="Search"
          aria-label="Search"
          value={input}
          onChange={handleInputChange}
        />
        <button className="btn btn-primary btn-search" type="submit">
          Search
        </button>
      </form>

      {/* Appointments List Table */}
      <div className="table-responsive">
        <table className="table table-responsive">
          <thead>
            <tr>
              <th scope="col" className='p-name' onClick={handleSortClick}>Patient Name
                <i className={`fa-solid ${sortOrder === 'ASC' ? 'fa-angle-up' : 'fa-angle-down'} mx-2`}></i>
              </th>
              <th scope="col">Doctor Name</th>
              <th scope="col">Appointment Date</th>
              <th scope="col">Appointment Type</th>
              <th scope="col">Accept</th>
              <th scope="col">Reject</th>
              <th scope="col">Status</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {appointmentsData?.data.length > 0 ? (
              appointmentsData?.data.map((appointment: any) => (
                <tr key={appointment.uuid}>
                  <td>{appointment.Patient?.firstname} {appointment.Patient?.lastname}</td>
                  <td>{appointment.User?.firstname} {appointment.User?.lastname}</td>
                  <td>{appointment.appointmentDate}</td>
                  <td>{appointment.appointmentType}</td>
                  <td>
                    {appointment.Patient?.referalstatus == 3 ? (
                      <button
                        className="btn btn-success"
                        onClick={() => handleAccept(appointment?.Patient?.uuid)}
                        style={{ padding: 3 }}
                      >
                        Accept
                      </button>
                    ) : (
                      <span>-</span>
                    )}
                  </td>
                  <td>
                    {appointment.Patient?.referalstatus == 3 ? (
                      <button
                        className="btn btn-danger"
                        onClick={() => handleReject(appointment?.Patient?.uuid)}
                        style={{ padding: 3 }}
                      >
                        Reject
                      </button>
                    ) : (
                      <span>-</span>
                    )}
                  </td>
                  <td>
                    {appointment.Patient?.referalstatus == 1 && (
                      <span className="text-success-1">Completed</span>
                    )}
                    {appointment.Patient?.referalstatus == 0 && (
                      <span className="text-rejected-1">Rejected</span>
                    )}
                    {appointment.Patient?.referalstatus == 2 && (
                      <span className="text-pending-1">Pending</span>
                    )}
                    {appointment.Patient?.referalstatus == 3 && (
                      <span className="text-scheduled-1">Scheduled</span>
                    )}
                  </td>


                  <td style={{ width: 100 }}>
                    <Link to={`/appointment-details/${appointment.uuid}`}>
                      <i className="fa-solid fa-eye view-icon" style={{ paddingRight: 6 }} title='Details'></i>
                    </Link>
                    <Link to={`/update-appointment/${appointment.uuid}`}>
                      <i className="fa-regular fa-pen-to-square update-icon" title='Update'></i>
                    </Link>
                  </td>
                </tr>
              ))) : (
              <tr><td colSpan={6}>No Appointments Found</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      <Pagination
        totalPages={totalPages}
        currentPage={currentPage}
        handlePageChange={handlePageChange}
      />
    </div>
  );
};

export default AppointmentsList;
