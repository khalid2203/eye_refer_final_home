/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { createContext, useContext } from 'react';
import { toast } from 'react-toastify';
import { useQuery } from '@tanstack/react-query';
import api from '../../api/axiosInstance';
import { Local } from '../../environment/env';

interface User {
    uuid: string;
    referCount: number;
    referCompleted: number;
    docCount: number;
    data: any
}

interface UserContextType {
    userData: User | null;
    isLoading: boolean;
    error: string | null;
}

const UserContext = createContext<any | undefined>(undefined);

const UserProvider: React.FC<any> = ({ children }) => {
    const token = localStorage.getItem("token");

    const getUser = async () => {
        try {
            const response = await api.get(`${Local.GET_USER}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            return response;
        } catch (err) {
            console.log(err);

            toast.error("Failed to fetch user data");
        }
    };

    const { data, isLoading, error } = useQuery({
        queryKey: ['userData'],
        queryFn: getUser
    });


    const value = {
        userData: data || null,
        isLoading,
        error: error ? "Failed to fetch user data" : null,
    };

    return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
};

const useUser = (): UserContextType => {
    const context = useContext(UserContext);
    if (!context) {
        throw new Error('useUser must be used within a UserProvider');
    }
    return context;
};

export { UserProvider, useUser };
