import { toast } from "react-toastify";
import api from "../api/axiosInstance";
import { Local } from "../environment/env";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import '../../src/css/Notification.css'
import moment from "moment";
import { useEffect, useState } from "react";

const Notifiactions: React.FC = () => {
    const token: any = localStorage.getItem("token");
    const queryClient = useQueryClient();
    const [isReadMarked, setIsReadMarked] = useState(false);

    const getNotifications = async () => {
        try {
            const response = await api.get(`${Local.GET_NOTIFICATIONS}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            return response?.data;
        } catch (err: any) {
            console.log(err);
            toast.error("Failed to fetch notifications");
        }
    };

    const { data: notifications } = useQuery({
        queryKey: ['notification'],
        queryFn: getNotifications
    });

    console.log("notificationssss--------", notifications);

    const markNotificationsAsRead = async () => {
        try {
            // Only mark as read if it hasn't been done yet
            if (!isReadMarked) {
                await api.put(`${Local.MARK_READ}`, {}, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setIsReadMarked(true); // Update state to prevent further calls
            }
        } catch (err: any) {
            console.log("Error marking notifications as read", err.message);
            toast.error("Failed to mark notifications as read");
        }
    };

    useEffect(() => {
        if (notifications && notifications.length > 0 && !isReadMarked) {
            markNotificationsAsRead();
        }
        queryClient.invalidateQueries({ queryKey: ['userData'] });

    }, [notifications, isReadMarked]);


    const deleteNotification = useMutation({
        mutationFn: async (notificationId: string) => {
            try {
                const response = await api.delete(`${Local.DELETE_NOTIFICATION}/${notificationId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                return response.data;
            } catch (err: any) {
                throw new Error(`${err.message || 'Error deleting appointment'}`);
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['notification'] });
            toast.success('Notification deleted successfully');
        },
        onError: (err) => {
            toast.error(`Error: ${err.message}`);
        },
    });

    const handleDeleteNotification = (notificationId: string) => {
        deleteNotification.mutate(notificationId);
    };


    return (
        <div className="notification-container">
            <h5>Notifications</h5>
            <div className="notifications">
                {notifications?.length > 0 ? (
                    notifications?.map((notification: any) => (
                        <div key={notification?.id}>
                            <div className="notification-content d-flex align-items-center justify-content-between">
                                <div className="d-flex align-items-center">
                                    <img className="p-img" src={notification?.User?.profile_photo ? Local.BASE_URL + notification?.User?.profile_photo : 'profile1.png'} alt="profile" />
                                    <div>
                                        <div className="font-weight-bold">{notification?.User?.firstname} {notification?.User?.lastname}</div>
                                        <span>{notification?.notifications}</span>
                                    </div>
                                </div>
                                <div>
                                    <small className="time-received text-secondary">{moment(notification?.createdAt).calendar()}</small>
                                    <span className="delete-icon-1"><i
                                        className="fa-solid fa-trash text-danger"
                                        onClick={() => handleDeleteNotification(notification.id)}
                                    >
                                    </i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    ))) : (
                    <div><span>No Notification Found</span></div>
                )}
            </div>
        </div>
    )
}

export default Notifiactions;