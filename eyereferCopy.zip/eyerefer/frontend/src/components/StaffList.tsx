/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Local } from '../environment/env';
import api from '../api/axiosInstance';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Modal, Form, Button } from 'react-bootstrap';
import { Formik } from 'formik';
import * as Yup from 'yup';
import '../css/StaffList.css';
import { saveAs } from 'file-saver';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import Pagination from './Pagination';

const StaffList: React.FC = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  const queryClient = useQueryClient();


  const [showAddStaffModal, setShowAddStaffModal] = useState(false);
  const [newStaffData, setNewStaffData] = useState({
    firstname: '',
    lastname: '',
    gender: '',
    email: '',
    phoneNumber: '',
  });

  const [loading, setLoading] = useState(false);

  const [page, setPage] = useState(1);
  const [limit] = useState(4);
  const [search, setSearch] = useState('');
  const [input, setInput] = useState('');
  const [sortOrder, setSortOrder] = useState('DESC'); // Default sort order for createdAt


  const handleOpenAddStaffModal = () => setShowAddStaffModal(true);
  const handleCloseAddStaffModal = () => {
    setShowAddStaffModal(false);
    setNewStaffData({
      firstname: '',
      lastname: '',
      gender: '',
      email: '',
      phoneNumber: '',
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewStaffData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleAddStaffSubmit = async (values: any) => {
    if (!token || !values) return;

    setLoading(true);

    try {
      await api.post(
        `${Local.BASE_URL}${Local.ADD_STAFF}`,
        values,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      await queryClient.invalidateQueries();

      toast.success('Staff added successfully!');
      setShowAddStaffModal(false);
    } catch (err: any) {
      toast.error(`${err.response?.data?.message || 'Something went wrong'}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
  };

  const fetchStaff = async () => {
    try {
      const response = await api.get(`${Local.GET_STAFF}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        params: {
          page,
          limit,
          search,
          order: sortOrder
        },
      });
      return response.data;
    } catch (err: any) {
      toast.error(`${err.message || 'Error fetching staff data'}`);
    }
  };

  const { data: staffData, error, isLoading, isError } = useQuery({
    queryKey: ['staff', page, search, sortOrder],
    queryFn: fetchStaff,
  });

  const totalPages = staffData?.pagination?.totalPages || 1;
  const currentPage = staffData?.pagination?.currentPage || 1;

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setPage(newPage);
    }
  };

  const handleSortClick = () => {
    setSortOrder(sortOrder === 'ASC' ? 'DESC' : 'ASC');
    // fetchDoctor()
  };

  const downloadStaffcsv = async () => {
    try {
      const response = await api.get(`${Local.BASE_URL}download-staff`, {
        headers: {
          Authorization: `Bearer ${token}`,
          responseType: 'text',
        },
      });

      console.log("downloaddata", response.data);

      const blob = new Blob([response.data], { type: 'text/csv' });

      saveAs(blob, 'stafflist.csv');

    } catch (err: any) {
      toast.error(`${err.message || 'Error fetching staff data'}`);
    }
  };



  const downloadStaffAsPdf = async () => {
    const token = localStorage.getItem('token');
    try {
      const response = await api.get(`${Local.BASE_URL}download-staff`, {
        headers: {
          Authorization: `Bearer ${token}`,
          responseType: 'text',
        },
      });

      const csvData = response.data;

      const doc: any = new jsPDF();

      const rows = csvData
        .split('\n')
        .map((row: string) =>
          row
            // eslint-disable-next-line no-useless-escape
            .replace(/\"/g, '')
            .split(',')
        );

      doc.autoTable({
        head: [rows[0]],
        body: rows.slice(1),
      });

      doc.save('stafflist.pdf');

    } catch (err: any) {
      toast.error(`${err.message || 'Error fetching staff data'}`);
    }
  };



  const deleteAppointmentMutation = useMutation({
    mutationFn: async (staffId: string) => {
      try {
        const response = await api.delete(`${Local.DELETE_STAFF}/${staffId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        return response.data;
      } catch (err: any) {
        throw new Error(`${err.message || 'Error deleting appointment'}`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['staff'] });
      toast.success('Staff deleted successfully');
    },
    onError: (err) => {
      toast.error(`Error: ${err.message}`);
    },
  });

  const handleDeleteAppointment = (appointmentId: string) => {
    if (window.confirm('Are you sure you want to delete this staff?')) {
      deleteAppointmentMutation.mutate(appointmentId);
    }
  };

  const validationSchema = Yup.object({
    firstname: Yup.string()
      .required('First name is required')
      .min(2, 'First name must be at least 2 characters')
      .max(50, 'First name can\'t be more than 50 characters')
      .matches(/^[A-Za-z]+$/, 'First name must only contain letters'),

    lastname: Yup.string()
      .required('Last name is required')
      .min(2, 'Last name must be at least 2 characters')
      .max(50, 'Last name can\'t be more than 50 characters')
      .matches(/^[A-Za-z]+$/, 'Last name must only contain letters'),

    phoneNumber: Yup.string()
      .required('Phone number is required')
      .matches(/^[0-9]{10}$/, 'Phone number must be exactly 10 digits'),
  });

  useEffect(() => {
    if (!token) {
      navigate('/login');
    }
  }, [token, navigate]);

  if (isLoading) {
    return (
      <div className="loading-container">
        <div>Loading...</div>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="text-danger">
        Error: {error.message || 'Failed to load staff data'}
      </div>
    );
  }

  return (
    <div className="staff-list-container">
      <div className="staff-list-header">
        <h5 className="staff-list-title">Staff List</h5>

        <div className="add-staff-button">
          <button
            onClick={handleOpenAddStaffModal}
            className="add-staff-btn mb-4"
            disabled={loading}
          >
            {loading ? 'Adding Staff...' : 'Add Staff'}
          </button>
        </div>
      </div>

      <form onSubmit={handleSearchSubmit} className="d-flex mb-4 search-b" role="search">
        <input
          className="form-control input-field"
          type="search"
          placeholder="Search"
          aria-label="Search"
          value={input}
          onChange={(e: any) => setInput(e.target.value)}
        />
        <button className="btn btn-primary btn-search" type="submit" onClick={() => {
          setSearch(input);
        }}>
          Search
        </button>
      </form>
      <div className="download-btn d-flex">
        <div onClick={downloadStaffcsv} className="btn btn-primary"><i className="fa-solid fa-download"></i> csv</div>
        <div onClick={downloadStaffAsPdf} className="btn btn-primary">
          <i className="fa-solid fa-download"></i> PDF
        </div>
      </div>
      {/* Staff List Table */}
      <div className="table-responsive">
        <table className="table table-responsive">
          <thead>
            <tr>
              <th scope="col" className='p-name' onClick={handleSortClick}>First Name
                <i className={`fa-solid ${sortOrder === 'ASC' ? 'fa-angle-up' : 'fa-angle-down'} mx-2`}></i>
              </th>
              <th scope="col">Last Name</th>
              <th scope="col">Gender</th>
              <th scope="col">Email</th>
              <th scope="col">Phone Number</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {staffData?.data?.length > 0 ? (
              staffData?.data?.map((staff: any) => (
                <tr key={staff.uuid}>
                  <td>{staff.firstname}</td>
                  <td>{staff.lastname}</td>
                  <td>{staff.gender}</td>
                  <td>{staff.email}</td>
                  <td>{staff.phoneNumber}</td>
                  <td><i
                    className="fa-solid fa-trash text-danger delete-icon" title='Delete'
                    onClick={() => handleDeleteAppointment(staff.uuid)}
                  >
                  </i>
                  </td>
                </tr>
              ))) : (
              <tr><td colSpan={5}>No Staff Found</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <Pagination
        totalPages={totalPages}
        currentPage={currentPage}
        handlePageChange={handlePageChange}
      />

      {/* Add Staff Modal */}
      <Modal show={showAddStaffModal} onHide={handleCloseAddStaffModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Add New Staff</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Formik
            initialValues={newStaffData}
            validationSchema={validationSchema}
            onSubmit={handleAddStaffSubmit}
          >
            {({ handleSubmit, handleChange, values, touched, errors }) => (
              <Form onSubmit={handleSubmit}>
                <Form.Group controlId="firstname">
                  <Form.Label className="required">First Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="firstname"
                    value={values.firstname}
                    onChange={handleChange}
                    isInvalid={touched.firstname && !!errors.firstname}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.firstname}
                  </Form.Control.Feedback>
                </Form.Group>

                <Form.Group controlId="lastname">
                  <Form.Label className="required">Last Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="lastname"
                    value={values.lastname}
                    onChange={handleChange}
                    isInvalid={touched.lastname && !!errors.lastname}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.lastname}
                  </Form.Control.Feedback>
                </Form.Group>

                <Form.Group controlId="gender">
                  <Form.Label className="required">Gender</Form.Label>
                  <Form.Control
                    as="select"
                    name="gender"
                    value={values.gender}
                    onChange={handleChange}
                    isInvalid={touched.gender && !!errors.gender}
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </Form.Control>
                  <Form.Control.Feedback type="invalid">
                    {errors.gender}
                  </Form.Control.Feedback>
                </Form.Group>

                <Form.Group controlId="email">
                  <Form.Label className="required">Email</Form.Label>
                  <Form.Control
                    type="email"
                    name="email"
                    value={values.email}
                    onChange={handleChange}
                    isInvalid={touched.email && !!errors.email}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.email}
                  </Form.Control.Feedback>
                </Form.Group>

                <Form.Group controlId="phoneNumber">
                  <Form.Label className="required">Phone Number</Form.Label>
                  <Form.Control
                    type="text"
                    name="phoneNumber"
                    value={values.phoneNumber}
                    onChange={handleChange}
                    isInvalid={touched.phoneNumber && !!errors.phoneNumber}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.phoneNumber}
                  </Form.Control.Feedback>
                </Form.Group>

                <Modal.Footer>
                  <Button variant="secondary" onClick={handleCloseAddStaffModal}>
                    Close
                  </Button>
                  <Button
                    variant="primary"
                    type="submit"
                  >
                    Add Staff
                  </Button>
                </Modal.Footer>
              </Form>
            )}
          </Formik>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default StaffList;
