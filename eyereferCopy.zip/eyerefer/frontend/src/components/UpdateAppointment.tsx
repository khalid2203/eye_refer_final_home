import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { toast } from "react-toastify";
import { Local } from "../environment/env";
import api from "../api/axiosInstance";
import "../css/UpdateAppointment.css";

const UpdateAppointment: React.FC = () => {
    const { appointmentId } = useParams<{ appointmentId: string }>();
    const navigate = useNavigate();
    const token = localStorage.getItem("token");
    const [patientName, setPatientName] = useState<string>();

    const [initialValues, setInitialValues] = useState({
        appointmentDate: "",
        appointmentType: "",
        // firstname: "",
        patientId: ""
    });
    const [isLoading, setIsLoading] = useState(true);

    // Validation schema using Yup
    const validationSchema = Yup.object({
        appointmentDate: Yup.date().required("Appointment date is required"),
        appointmentType: Yup.string()
            .oneOf(["Consultation", "Surgery"], "Invalid appointment type")
            .required("Appointment type is required"),
    });

    // Fetch existing appointment details
    useEffect(() => {
        const fetchAppointmentDetails = async () => {
            try {
                const response = await api.get(
                    `${Local.VIEW_APPOINTMENT}/${appointmentId}`,
                    {
                        headers: {
                            Authorization: `Bearer ${token}`,
                        },
                    }
                );
                console.log("aaaaaaaaaaa", response.data);


                const { appoinmentDetails } = response.data;
                const { patient } = response.data;
                setPatientName(patient.firstname + " " + patient.lastname)
                setInitialValues({
                    patientId: patient.uuid,
                    // firstname: patient.firstname + " " + patient.lastname || "",
                    appointmentDate: appoinmentDetails.appointmentDate || "",
                    appointmentType: appoinmentDetails.appointmentType || "",
                });
            } catch (error) {
                toast.error("Failed to fetch appointment details");
                console.error(error);
            } finally {
                setIsLoading(false);
            }
        };

        if (token) {
            fetchAppointmentDetails();
        } else {
            navigate("/login");
        }
    }, [appointmentId, token, navigate]);

    // Submit handler for the form
    const handleSubmit = async (values: typeof initialValues) => {
        try {
            const response = await api.put(
                `${Local.UPDATE_APPOINTMENT}/${appointmentId}`,
                values,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );
            toast.success(response.data.message || "Appointment updated successfully");
            navigate(-1);
        } catch (error) {
            toast.error("Failed to update appointment");
            console.error(error);
        }
    };

    console.log("aaappointype", initialValues)

    if (isLoading) {
        return (
            <div className="spinner-border text-primary" role="status">
                <span className="visually-hidden">Loading...</span>
            </div>
        );
    }

    return (
        <div className="update-appointment-container">
            <h5 className="form-title">Update Appointment</h5>
            <Formik
                initialValues={initialValues}
                enableReinitialize={true}
                validationSchema={validationSchema}
                onSubmit={handleSubmit}
            >
                {() => (
                    <Form className="form-container">
                        <div className="row">
                            <div className="form-group mb-3 col">
                                <label htmlFor="appointmentDate">Patient Name</label>
                                <Field
                                    type="text"
                                    id="firstname"
                                    // value={`${firstname}`}
                                    value={patientName}
                                    name="firstname"
                                    className="form-control"
                                    disabled
                                />
                            </div>
                            <div className="form-group mb-3 col">
                                <label htmlFor="appointmentDate">Appointment Date</label>
                                <Field
                                    type="date"
                                    id="appointmentDate"
                                    name="appointmentDate"
                                    className="form-control"
                                    onClick={(e: any) => e.target.showPicker()}
                                />
                                <ErrorMessage
                                    name="appointmentDate"
                                    component="div"
                                    className="text-danger"
                                />
                            </div>

                            <div className="form-group mb-3 col">
                                <label htmlFor="appointmentType">Appointment Type</label>
                                <Field
                                    as="select"
                                    id="appointmentType"
                                    name="appointmentType"
                                    className="form-control"
                                >
                                    <option value="">Select type</option>
                                    <option value="Consultation">Consultation</option>
                                    <option value="Surgery">Surgery</option>
                                </Field>
                                <ErrorMessage
                                    name="appointmentType"
                                    component="div"
                                    className="text-danger"
                                />
                            </div>
                        </div>
                        <button
                            type="submit"
                            className="btn btn-primary"

                        >
                            Update Appointment
                        </button>
                        <Link className="btn btn-secondary" to="/dashboard">Back</Link>
                    </Form>
                )}
            </Formik>
        </div>
    );
};

export default UpdateAppointment;