import React, { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Local } from "../environment/env";
import api from "../api/axiosInstance";
import { toast } from "react-toastify";
import moment from "moment";
import "../css/ViewAppointment.css";

const AppointmentDetails: React.FC = () => {
    const { appointmentId } = useParams<{ appointmentId: string }>();
    const navigate = useNavigate();
    const token = localStorage.getItem("token");

    const getAppointmentDetails = async () => {
        try {
            console.log("Getting appointment details");
            const response = await api.get(
                `${Local.VIEW_APPOINTMENT}/${appointmentId}`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            return response.data;
        } catch (err) {
            toast.error("Failed to fetch appointment details");
            console.error(err);
        }
    };

    const {
        data: appointmentData,
        isLoading,
        isError,
        error,
    } = useQuery({
        queryKey: ["appointmentDetails", appointmentId],
        queryFn: getAppointmentDetails,
    });
    console.log(appointmentData);
    useEffect(() => {
        if (!token) {
            navigate("/login");
        }
    }, [token, navigate]);

    if (isLoading) {
        return (
            <div className="spinner-border text-primary" role="status">
                <span className="visually-hidden">Loading...</span>
            </div>
        );
    }

    if (isError) {
        return (
            <div className="text-danger">
                Error: {error instanceof Error ? error.message : "An error occurred"}
            </div>
        );
    }

    if (!appointmentData) {
        return <div>No appointment data available.</div>;
    }

    return (
        <div className="view-appointment-container">
            <div className="view-appointment-header">
                <h5 className="mb-4">Appointment Details</h5>
                <div className="appointment-details row">
                    <p className="col">

                        <span className="text-black">Patient Name:</span> {appointmentData?.patient?.firstname}{" "}
                        {appointmentData?.patient?.lastname}

                    </p>
                    <p className="col">
                        <span className="text-black">Appointment Date: </span>
                        {/* {moment(appointmentData?.appoinmentDetails?.appointmentDate).format("DD-MM-YYYY")} */}
                        {moment(appointmentData?.appoinmentDetails?.appointmentDate).format('ll')}
                    </p>
                    <p className="col">
                        <span className="text-black">Type: </span>
                        {appointmentData?.appoinmentDetails?.appointmentType}
                    </p>

                </div>
                <button className="btn btn-primary mx-0" onClick={() => navigate(-1)}>
                    Back
                </button>
            </div>
        </div>
    );
};

export default AppointmentDetails;