import React, { useEffect } from 'react';
import { Outlet, Link, useNavigate } from 'react-router-dom';
// import logo from '../Assets/title_logo.webp';
import '../css/Header.css';
import { Local } from '../environment/env';
import { toast } from 'react-toastify';
import { io } from 'socket.io-client';
import { useUser } from './context/UserContext';
import Logo from '../Images/logo1.png';
import ProfilePhoto from '../Images/profile1.png';
import { useQueryClient } from '@tanstack/react-query';

const socket = io(`${Local.BASE_URL}`);


const Header: React.FC = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  const doctype: any = localStorage.getItem('doctype');
  const { userData } = useUser();
  const queryClient = useQueryClient();

  // const firstname = localStorage.getItem("firstname");
  // console.log(firstname)


  const handleLogoClick = () => {
    navigate('/dashboard');
  };
  // const getUser = async () => {
  //   try {
  //     const response = await api.get(`${Local.GET_USER}`, {
  //       headers: {
  //         Authorization: `Bearer ${token}`
  //       }
  //     });
  //     return response;
  //   } catch (err) {
  //     console.log(err);
  //     toast.error("Failed to fetch user data");
  //   }
  // };

  // const { data: userData } = useQuery({
  //   queryKey: ['userData'],
  //   queryFn: getUser
  // });

  const { user } = userData?.data || {};

  // console.log("notificiaont", userData?.data?.notificationCount);


  useEffect(() => {
    if (!token) {
      navigate("/login");
    }
    socket.on('receive_notification', (data) => {
      if (data.receiverId === user?.uuid) {
        queryClient.invalidateQueries({ queryKey: ['userData'] });
        toast.success(`${data.message}`);
      }

    });

  }, [token, navigate, user?.uuid]);



  // console.log("userdata from header", userData?.data);
  return (
    <>

      <header className="header-container">

        <div className="header-left">


          {/* <img src='logo1.png' alt="loginbg" /> */}

        </div>


        <div className="header-right">
          <div className="user-actions">
            {token ? (
              <div className="btn-group">
                <div className="position-relative d-flex align-items-center flex-row bell-icon">

                  <Link className='text-black' to='/notifications'><i className="fa-solid fa-bell bell-button"></i></Link>

                  <span className="position-absolute top-5 start-40 translate-middle badge rounded-pill bg-danger">
                    {userData?.data?.notificationCount >= 5 ? "5+" : userData?.data?.notificationCount}
                    <span className="visually-hidden">unread messages</span>
                  </span>
                </div>
                <span className="dropdown-toggle font-weight-bold h5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  {/* <img src='profile1.png' className="dropdown-toggle1 mr-3" aria-expanded="false" /> */}

                  <img className="p-img" src={user?.profile_photo ? Local.BASE_URL + user?.profile_photo : ProfilePhoto} alt="profile" />
                  Hi,  {user?.firstname}
                  {/* <div>Welcome Back</div> */}
                </span>
                <div className="dropdown-menu">
                  <Link to="/profile" className="dropdown-item">
                    Profile
                  </Link>
                  <Link to="/update-password" className="dropdown-item">
                    Change Password
                  </Link>
                  <a className="dropdown-item" onClick={() => {
                    localStorage.clear();
                    navigate('/login');
                  }}>Logout <i className="fa-solid fa-arrow-right-from-bracket mx-2"></i></a>
                </div>
              </div>
            ) : (
              <>
                <Link to="/login" className="btn login-btn">
                  Login
                </Link>
                <Link to="/" className="btn signup-btn">
                  Sign-up
                </Link>
              </>
            )}
          </div>
        </div>
      </header>
      {/* <div className="header-divider"></div> */}
      {token && (
        <div className="sidebar bg-white">
          <div className="sidebar-logo">
            <div onClick={handleLogoClick} className="logo">
              <img src={Logo} alt="EyeRefer" className="logo1-img" />
              <span className='logo-text'>EYE REFER</span>
              <hr />
            </div>
          </div>

          <nav className="nav-links ">
            <Link to="/dashboard" className="nav-link">
              <i className="fas fa-home m-2"></i>
              Dashboard
            </Link>
            <Link to="/patient" className="nav-link ">
              <i className="fa-solid fa-bed m-2"></i>
              Patient
            </Link>
            {doctype === '1' && (
              <Link to="/appointments" className="nav-link">
                <i className="fas fa-calendar-alt m-2"></i>
                Appointments
              </Link>
            )}
            <Link to="/doctor" className="nav-link">
              <i className="fas fa-user-md m-2"></i>
              Doctors
            </Link>
            <Link to="/chat" className="nav-link">
              <i className="fas fa-comment m-2"></i>
              Chat
            </Link>
            <Link to="/staff" className="nav-link">
              <i className="fa-solid fa-people-group m-2"></i>
              Staff
            </Link>
            {/* {doctype === '2' && (
              <Link to="/add-patient" className="nav-link">
                <i className="fa-solid fa-share-from-square m-2"></i>
                Add Patient
              </Link>
            )} */}
          </nav>
        </div>
      )}
      {/* {userData?.data && <Graph userData={userData?.data} />} */}
      <Outlet />
    </>
  );
};

export default Header;
